"use strict";(()=>{var e={};e.id=197,e.ids=[197,888,660],e.modules={1323:(e,t)=>{Object.defineProperty(t,"l",{enumerable:!0,get:function(){return function e(t,r){return r in t?t[r]:"then"in t&&"function"==typeof t.then?t.then(t=>e(t,r)):"function"==typeof t&&"default"===r?t:void 0}}})},30516:(e,t,r)=>{r.r(t),r.d(t,{config:()=>L,default:()=>E,getServerSideProps:()=>H,getStaticPaths:()=>G,getStaticProps:()=>Z,reportWebVitals:()=>T,routeModule:()=>U,unstable_getServerProps:()=>B,unstable_getServerSideProps:()=>D,unstable_getStaticParams:()=>R,unstable_getStaticPaths:()=>O,unstable_getStaticProps:()=>M});var o={};r.r(o),r.d(o,{default:()=>I});var s=r(87093),n=r(35244),i=r(1323),a=r(25089),l=r(16967),p=r(20997);r(16689);var d=r(57518),c=r.n(d),g=r(37365),m=r.n(g),h=r(42042),u=r(13167),x=r(29559),b=r(1770),f=r(56081),w=r(86715),P=r(41607),y=r(87455),j=r(57416),S=r(51475);let v=c()(x.Z).withConfig({componentId:"sc-6c85e224-0"})(["padding:314px 0 var(--spacing);text-align:center;"," ",""],m().below(u.bp.desktop,`
    padding-top: 235px;
  `),m().below(u.bp.laptopSm,`
    padding-top: 157px;
  `)),q=c().div.withConfig({componentId:"sc-6c85e224-1"})(["position:relative;max-width:580px;margin:auto auto 40px;"," ",""],m().below(u.bp.desktop,`
    max-width: 435px;
    margin-bottom: 30px;
  `),m().below(u.bp.laptopSm,`
    max-width: 290px;
    margin-bottom: 20px;
  `)),A=c()(w.dx).withConfig({componentId:"sc-6c85e224-2"})(["",""],m().below(u.bp.portrait,`
    max-width: 480px;
    margin: auto;
    line-height: 1.2;
  `)),C=c().span.withConfig({componentId:"sc-6c85e224-3"})(["display:block;margin-top:15px;font-size:",";font-weight:700;text-transform:uppercase;"],(0,h.rem)(15)),k=c()(y.Z).withConfig({componentId:"sc-6c85e224-4"})(["position:relative;grid-template-columns:repeat(2,1fr);grid-column-gap:170px;max-width:1000px;margin:26px auto 34px;span{display:block;color:var(--gold);font-size:",";font-family:var(--secondary-font);}p{opacity:.6;&:first-of-type{margin-top:0;}&:last-of-type{margin-bottom:0;}}&::before{","}"," ",""],(0,h.rem)(18),m().above(u.bp.tablet,`
      position: absolute;
      top: 0;
      left: 50%;
      width: 1px;
      height: 100%;
      background-color: var(--brand-black);
      transform: translateX(-50%);
      content: "";
    `),m().below(u.bp.tablet,`
    grid-template-columns: 1fr;
    grid-row-gap: 40px;
    max-width: 450px;
  `),m().below(u.bp.mobile,`
    grid-row-gap: 20px;
    margin-bottom: 0;
  `)),_=()=>p.jsx(v,{hasPadding:!0,bgColor:"brand-white",children:(0,p.jsxs)(b.Z,{children:[p.jsx(f.Z,{as:"h1",children:"404"}),p.jsx(q,{children:p.jsx(S.Z,{src:"/images/404-duke.png",alt:"",width:580,height:415})}),p.jsx(A,{children:"We couldn't find the page you were looking for"}),p.jsx(C,{children:"This is Either Because:"}),(0,p.jsxs)(k,{as:P.Z,children:[(0,p.jsxs)("li",{children:[p.jsx("span",{children:"01"}),p.jsx("p",{children:"There is an error in the URL entered into your web browser. Please check the URL and try again."})]}),(0,p.jsxs)("li",{children:[p.jsx("span",{children:"02"}),p.jsx("p",{children:"The page you are looking for has been moved or deleted."})]})]}),p.jsx(j.Z,{href:"/",isdark:!0,bgcolor:"gold",large:!0,hasmargin:!0,children:"Back to Home"})]})}),I=()=>p.jsx(_,{}),E=(0,i.l)(o,"default"),Z=(0,i.l)(o,"getStaticProps"),G=(0,i.l)(o,"getStaticPaths"),H=(0,i.l)(o,"getServerSideProps"),L=(0,i.l)(o,"config"),T=(0,i.l)(o,"reportWebVitals"),M=(0,i.l)(o,"unstable_getStaticProps"),O=(0,i.l)(o,"unstable_getStaticPaths"),R=(0,i.l)(o,"unstable_getStaticParams"),B=(0,i.l)(o,"unstable_getServerProps"),D=(0,i.l)(o,"unstable_getServerSideProps"),U=new s.PagesRouteModule({definition:{kind:n.x.PAGES,page:"/404",pathname:"/404",bundlePath:"",filename:""},components:{App:l.default,Document:a.default},userland:o})},29559:(e,t,r)=>{r.d(t,{Z:()=>s});var o=r(57518);let s=r.n(o)().section.withConfig({componentId:"sc-cda045f2-0"})([""," ",""],e=>e.hasPadding&&`
    padding: var(--spacing) 0;
  `,e=>e.bgColor&&`
    background-color: var(--${e.bgColor});
  `)},56081:(e,t,r)=>{r.d(t,{Z:()=>l});var o=r(57518),s=r.n(o),n=r(580),i=r.n(n);let a=s().div.withConfig({componentId:"sc-3fe2092e-0"})(["position:absolute;top:0;left:-999px;clip:rect(0,0,0,0);pointer-events:none;"]);a.propTypes={as:i().string};let l=a},25089:(e,t,r)=>{r.r(t),r.d(t,{default:()=>g});var o=r(20997),s=r(16689),n=r.n(s),i=r(56859),a=r.n(i),l=r(12791),p=r(57518),d=r(4298),c=r.n(d);class g extends a(){static async getInitialProps(e){let t=new p.ServerStyleSheet,r=e.renderPage;try{e.renderPage=()=>r({enhanceApp:e=>r=>t.collectStyles(o.jsx(e,{...r}))});let s=await a().getInitialProps(e);return{...s,helmet:l.Helmet.renderStatic(),styles:(0,o.jsxs)(n().Fragment,{children:[s.styles,t.getStyleElement()]})}}finally{t.seal()}}get helmetHtmlAttrComponents(){return this.props.helmet.htmlAttributes.toComponent()}get helmetBodyAttrComponents(){return this.props.helmet.bodyAttributes.toComponent()}get helmetHeadComponents(){return Object.keys(this.props.helmet).filter(e=>"htmlAttributes"!==e&&"bodyAttributes"!==e).map(e=>this.props.helmet[e].toComponent())}get helmetJsx(){return o.jsx(l.Helmet,{})}render(){return(0,o.jsxs)(i.Html,{...this.helmetHtmlAttrComponents,children:[(0,o.jsxs)(i.Head,{children:[this.helmetJsx,this.helmetHeadComponents,o.jsx("link",{rel:"preconnect",href:"https://fonts.gstatic.com"}),o.jsx("link",{href:"https://fonts.googleapis.com/css2?family=Anton&display=swap",rel:"stylesheet"}),o.jsx(c(),{src:"https://www.googletagmanager.com/gtag/js?id=G-0DZLS1C28M",strategy:"afterInteractive"}),o.jsx(c(),{id:"google-analytics",strategy:"afterInteractive",children:`
              window.dataLayer = window.dataLayer || [];
              function gtag(){window.dataLayer.push(arguments);}
              gtag('js', new Date());
              gtag('config', 'G-0DZLS1C28M');
            `})]}),(0,o.jsxs)("body",{...this.helmetBodyAttrComponents,children:[o.jsx(i.Main,{}),o.jsx(i.NextScript,{})]})]})}}},35244:(e,t)=>{var r;Object.defineProperty(t,"x",{enumerable:!0,get:function(){return r}}),function(e){e.PAGES="PAGES",e.PAGES_API="PAGES_API",e.APP_PAGE="APP_PAGE",e.APP_ROUTE="APP_ROUTE"}(r||(r={}))},79715:e=>{e.exports=require("@prismicio/client")},44287:e=>{e.exports=require("gsap")},4965:e=>{e.exports=require("gsap/dist/ScrollTrigger")},62785:e=>{e.exports=require("next/dist/compiled/next-server/pages.runtime.prod.js")},42042:e=>{e.exports=require("polished")},580:e=>{e.exports=require("prop-types")},16689:e=>{e.exports=require("react")},66405:e=>{e.exports=require("react-dom")},12791:e=>{e.exports=require("react-helmet")},19785:e=>{e.exports=require("react-intersection-observer")},60929:e=>{e.exports=require("react-scrolllock")},84466:e=>{e.exports=require("react-transition-group")},20997:e=>{e.exports=require("react/jsx-runtime")},57518:e=>{e.exports=require("styled-components")},99816:e=>{e.exports=require("styled-jsx/style")},37365:e=>{e.exports=require("superior-mq")},48521:e=>{e.exports=require("use-is-tabbing")},16135:e=>{e.exports=require("use-onclickoutside")},57147:e=>{e.exports=require("fs")},71017:e=>{e.exports=require("path")},12781:e=>{e.exports=require("stream")},59796:e=>{e.exports=require("zlib")}};var t=require("../webpack-runtime.js");t.C(e);var r=e=>t(t.s=e),o=t.X(0,[808,878,803,967],()=>r(30516));module.exports=o})();
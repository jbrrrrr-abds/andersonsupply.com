var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/exit-preview.js")
R.c("server/chunks/[root-of-the-server]__8d54d4f7._.js")
R.c("server/chunks/[root-of-the-server]__d717aa4b._.js")
R.m(11063)
module.exports=R.m(11063).exports

var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/exit-preview.js")
R.c("server/chunks/[root-of-the-server]__ad7094eb._.js")
R.c("server/chunks/[root-of-the-server]__28b8095e._.js")
R.m(81722)
module.exports=R.m(81722).exports

var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/preview.js")
R.c("server/chunks/[root-of-the-server]__90be2c7d._.js")
R.c("server/chunks/[root-of-the-server]__d717aa4b._.js")
R.m(9826)
module.exports=R.m(9826).exports

var R=require("../../chunks/[turbopack]_runtime.js")("server/pages/api/preview.js")
R.c("server/chunks/[root-of-the-server]__4ad38f44._.js")
R.c("server/chunks/[root-of-the-server]__28b8095e._.js")
R.m(589)
module.exports=R.m(589).exports

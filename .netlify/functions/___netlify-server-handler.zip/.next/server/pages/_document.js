var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__5469e3ec._.js")
R.c("server/chunks/ssr/[root-of-the-server]__37df9337._.js")
R.m(67684)
module.exports=R.m(67684).exports

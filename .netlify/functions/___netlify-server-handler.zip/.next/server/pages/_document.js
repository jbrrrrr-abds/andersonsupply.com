var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_document.js")
R.c("server/chunks/ssr/[root-of-the-server]__929865cf._.js")
R.c("server/chunks/ssr/[root-of-the-server]__f37faad4._.js")
R.m(67684)
module.exports=R.m(67684).exports

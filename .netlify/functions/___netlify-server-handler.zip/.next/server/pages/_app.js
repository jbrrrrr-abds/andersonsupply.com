var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/_app.js")
R.c("server/chunks/ssr/[root-of-the-server]__267a8324._.js")
R.c("server/chunks/ssr/[root-of-the-server]__fd829b1d._.js")
R.c("server/chunks/ssr/[root-of-the-server]__ae2288a9._.js")
R.m(76695)
module.exports=R.m(76695).exports

var R=require("../chunks/ssr/[turbopack]_runtime.js")("server/pages/confirmed.js")
R.c("server/chunks/ssr/[root-of-the-server]__64d98999._.js")
R.c("server/chunks/ssr/[root-of-the-server]__8f98b617._.js")
R.c("server/chunks/ssr/[root-of-the-server]__929865cf._.js")
R.c("server/chunks/ssr/[root-of-the-server]__f37faad4._.js")
R.c("server/chunks/ssr/[root-of-the-server]__267a8324._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1c7ee529._.js")
R.m(48788)
module.exports=R.m(48788).exports

module.exports=[10424,a=>{"use strict";var b=a.i(46283);let c=b.default.section.withConfig({displayName:"Section",componentId:"sc-47f70e12-0"})`
  ${a=>a.hasPadding&&`
    padding: var(--spacing) 0;
  `}

  ${a=>a.bgColor&&`
    background-color: var(--${a.bgColor});
  `}
`;a.s(["default",0,c])},37336,a=>{"use strict";var b=a.i(8171);a.i(27669);var c=a.i(27899),d=a.i(46283),e=a.i(74852),f=a.i(93631),g=a.i(10424),h=a.i(68178);let i=(0,d.default)(g.default).withConfig({displayName:"Hero__StyledSection",componentId:"sc-7c6cca94-0"})`
  position: relative;
  z-index: 1;
  padding: 320px 0 var(--spacing);
  color: var(--brand-white);
  background: var(--brand-black);

  .hero {
    width: 100%;
    max-width: 1080px;
    margin: 0 auto 5rem;
    text-align: center;
    padding: 0 30px;

    img {
      max-width: 316px;
      margin: 10px auto 40px;

      @media screen and (width <= 1080px) {
        max-width: 70vw;
        margin: 2vw auto 4vw;
      }
    }

    @media screen and (width <= 1080px) {
      padding: 0 5vw;
    }
  }

  h1 {
    font-family: var(--tertiary-font);
    font-size: 4rem;
    line-height: 1.2;
    font-weight: 900;
    margin-bottom: 20px;

    @media screen and (width <= 1080px) {
      font-size: 12vw;
    }
  }

  h2 {
    font-family: var(--tertiary-font);
    font-size: 2.4rem;
    line-height: 1.2;

    @media screen and (width <= 1080px) {
      font-size: 8vw;
    }
  }

  h3 {
    font-family: var(--tertiary-font);
    font-size: 4rem;
    line-height: 1.2;
    margin-bottom: 20px;

    @media screen and (width <= 1080px) {
      font-size: 12vw;
      margin-bottom: 3vw;
    }
  }

  h4 {
    font-family: var(--tertiary-font);
    font-size: 2.4rem;
    line-height: 1.2;
    padding-bottom: 200px;

    @media screen and (width <= 800px) {
      font-size: 8vw;
    }
  }

  p {
    text-align: center;

    &:last-of-type {
      margin-bottom: 0;
    }
  }

  ${e.default.below(f.bp.desktopSm,`
    padding-top: 240px;
  `)}

  ${e.default.below(f.bp.laptopSm,`
    padding-bottom: 0;
  `)}

  ${e.default.below(f.bp.portrait,`
    padding-top: 160px;
  `)}
`;d.default.div.withConfig({displayName:"Hero__Image",componentId:"sc-7c6cca94-1"})`
  position: relative;
  width: 967px;
  height: 580px;
  margin: auto;

  img {
    z-index: -1;
    opacity: 0.75;
    filter: grayscale(100%);
  }

  ${e.default.above(f.bp.laptopSm,`
    position: absolute;
    right: var(--container-gutter);
    bottom: 114px;
  `)}

  ${e.default.below(f.bp.desktop,`
    width: 725px;
    height: 435px;
  `)}

  ${e.default.below(f.bp.laptopSm,`
    width: auto;
    height: auto;
    margin-top: 75px;
  `)}
`,d.default.div.withConfig({displayName:"Hero__Content",componentId:"sc-7c6cca94-2"})`
  padding-left: var(--customer-container-gutter);
`;let j=({content:a})=>(0,b.jsx)("main",{children:(0,b.jsx)(i,{children:(0,b.jsx)(h.default,{children:(0,b.jsxs)("div",{className:"hero",children:[a?.title?(0,b.jsx)("h1",{children:a.title[0].text}):null,a?.subtitle?(0,b.jsx)("h2",{children:a.subtitle[0].text}):null,a?.main_image?(0,b.jsx)("img",{src:a.main_image.url,alt:a.main_image.alt}):null,a?.text_line_1?(0,b.jsx)("h3",{children:a.text_line_1[0].text}):null,a?.text_line_2?(0,b.jsx)("h4",{children:a.text_line_2[0].text}):null]})})})});j.propTypes={title:c.default.string,subTitle:c.default.string,mainImage:c.default.array,textLine1:c.default.object,textLine2:c.default.string},a.s(["default",0,j])},75783,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(65762),f=a.i(47659),g=a.i(37336),h=b([f]);async function i({preview:a,previewData:b}){let c=(0,f.createClient)({previewData:b});return{props:{page:await c.getSingle("we_got_you")||{}}}}[f]=h.then?(await h)():h,a.s(["default",0,({page:a})=>{if(!a)return null;let{data:b}=a;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.Helmet,{title:b?.page_title,meta:[{name:"description",content:b?.page_description},{property:"og:title",content:b?.page_title},{property:"og:description",content:b?.page_description},{property:"og:image",content:`${b?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:image",content:`${b?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:title",content:b?.page_title},{name:"twitter:description",content:b?.page_description},{name:"robots",content:"noindex"}]}),(0,d.jsx)(g.default,{content:b})]})},"getStaticProps",()=>i]),c()}catch(a){c(a)}},!1),74266,a=>a.a(async(b,c)=>{try{var d=a.i(43308),e=a.i(81245),f=a.i(42158),g=a.i(67684),h=a.i(76695),i=a.i(75783),j=a.i(42369),k=b([h,i]);[h,i]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/we-got-you",pathname:"/we-got-you",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/we-got-you",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_55e70bfa._.js.map
module.exports=[52227,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(46283),f=a.i(74852),g=a.i(93631),h=a.i(760),i=a.i(15749),j=b([i]);[i]=j.then?(await j)():j;let k=(0,e.default)(h.default).withConfig({displayName:"ImageWithText__StyledGrid",componentId:"sc-6c994d99-0"})`
  grid-template-columns: ${a=>a.imageLeft?"1.26fr 1fr":"1fr 1.26fr"};
  gap: 170px;
  align-items: center;

  ${f.default.below(g.bp.desktop,`
    grid-gap: 128px;
  `)}

  ${f.default.below(g.bp.desktopSm,`
    grid-template-columns: repeat(2, 1fr);
    grid-gap: 85px;
  `)}

  ${f.default.below(g.bp.tablet,`
    grid-template-columns: 1fr;
    grid-gap: 40px;
    align-items: start;
  `)}
`,l=(0,e.default)(i.default).withConfig({displayName:"ImageWithText__Image",componentId:"sc-6c994d99-1"})`
  order: ${a=>a.imageLeft?"1":"2"};

  ${f.default.below(g.bp.tablet,`
    order: 2;
  `)}
`,m=e.default.div.withConfig({displayName:"ImageWithText__Content",componentId:"sc-6c994d99-2"})`
  order: ${a=>a.imageLeft?"2":"1"};

  ${f.default.below(g.bp.tablet,`
    order: 1;
  `)}
`;a.s(["default",0,({imageLeft:a,children:b,className:c,image:e})=>{let f=e?.dimensions?.width||0,g=e?.dimensions?.height||0;return(0,d.jsxs)(k,{imageLeft:a,className:c,children:[e?.url?(0,d.jsx)(l,{width:f,height:g,src:`${e?.url||""}&w=${f}&h=${g}&fit=crop&q=85&f=center`,alt:e?.alt||"",imageLeft:a}):null,b?(0,d.jsx)(m,{imageLeft:a,children:b}):null]})}]),c()}catch(a){c(a)}},!1),21207,(a,b,c)=>{b.exports=a.x("flickity",()=>require("flickity"))},35688,a=>{"use strict";var b=a.i(8171),c=a.i(27669),d=a.i(46283),e=a.i(27899),f=a.i(93631),g=a.i(15935),h=a.i(92593);let i=d.default.div.withConfig({displayName:"Carousel",componentId:"sc-36d723c4-0"})`
  position: relative;
  overflow: hidden;
  outline: none;
  width: 100%;

  .flickity-viewport {
    position: relative;
  }

  .flickity-slider {
    width: 100%;
    height: 100%;
  }
`;i.Slide=d.default.div.withConfig({displayName:"Carousel__Slide",componentId:"sc-36d723c4-1"})`
  width: 100%;
  opacity: 0;
  transition: opacity 300ms ease-in-out;

  &.is-selected {
    opacity: 1;
  }
`;let j=d.default.li.withConfig({displayName:"Carousel__SlideDot",componentId:"sc-36d723c4-2"})`
  display: inline-block;

  &:not(:last-of-type) {
    margin-right: 10px;
  }
`,k=(0,d.default)(h.default).withConfig({displayName:"Carousel__SlideDotButton",componentId:"sc-36d723c4-3"})`
  width: 7px;
  height: 7px;
  position: relative;
  display: inline-block;
  background-color: var(--${a=>a.isDark?"brand-white":"gold"});
  border-radius: 50%;
  transition: opacity .33s;
  opacity: .5;

  &[aria-current="true"] {
    opacity: 1;
  }

  /* expand the click area as much as possible */

  &::before {
    content: "";
    display: block;
    position: absolute;
    inset: -6px;
  }

  ${(0,f.hover)(`
    opacity: 1;
  `)}
`,l=(0,d.default)(h.default).withConfig({displayName:"Carousel__SlideArrowButton",componentId:"sc-36d723c4-4"})`
  ${a=>a.color&&`
    color: var(--${a.color});
  `}
  ${a=>a.isLeft&&"transform: scaleX(-1)"};
  transition: color 300ms ease-in-out;

  ${(0,f.hover)(`
    color: var(--gold);
  `)}
`,m=d.default.svg.withConfig({displayName:"Carousel__SlideArrow",componentId:"sc-36d723c4-5"})`
  width: 32px;
  height: 8px;
  color: inherit;
`;i.Dots=({slides:a=[],currentIndex:c,handleClick:d,className:e,isDark:f})=>(i.Dots.displayName="CarouselDots",!a||a&&a.length<2)?null:(0,b.jsx)(g.default,{className:e,children:a.map((a,e)=>(0,b.jsx)(j,{display:"inline-block",children:(0,b.jsx)(k,{"aria-label":`Go to slide ${e+1}`,"aria-current":e===c,isDark:f,onClick:()=>{d(e)}})},e))}),i.Dots.propTypes={slides:e.default.array,currentIndex:e.default.number,handleClick:e.default.func,className:e.default.string},i.Button=({slideCount:a,currentIndex:c,handleClick:d,actionName:e,isLeft:f,color:g})=>{i.Button.displayName="CarouselButton";let h=null,j="next"===e?1:-1;return h=c+j>=a?0:c+j<0?a-1:c+j,(0,b.jsx)(l,{"aria-label":`Go to ${e} slide`,onClick:()=>{d(h)},actionName:e,isLeft:f,color:g,children:(0,b.jsx)(m,{viewBox:"0 0 32 8",isLeft:f,fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,b.jsx)("path",{d:"M3.99 5H31.5V3H3.99V0L0 4l3.99 4V5z",fill:"currentColor"})})})},a.s(["default",0,i,"useCarousel",0,(b={})=>{let[d,e]=(0,c.useState)(0),f=(0,c.useRef)(),g=(0,c.useCallback)(c=>{if(null!==c){let d=new(a.r(21207))(c,{prevNextButtons:!1,pageDots:!1,wrapAround:!0,dragThreshold:5,...b});f.current=d,d.on("dragStart",()=>{document.ontouchmove=a=>{a.preventDefault()}}),d.on("dragEnd",()=>{document.ontouchmove=()=>!0})}},[f,b]);return(0,c.useEffect)(()=>{f&&f.current&&f.current.on("change",a=>{e(a)})},[f]),(0,c.useEffect)(()=>()=>{f.current&&f.current.destroy()},[f]),{flickity:g,flickityIndex:d,setFlickityIndex:a=>{f&&f.current&&f.current.select(a,!0)}}}])},10424,a=>{"use strict";var b=a.i(46283);let c=b.default.section.withConfig({displayName:"Section",componentId:"sc-47f70e12-0"})`
  ${a=>a.hasPadding&&`
    padding: var(--spacing) 0;
  `}

  ${a=>a.bgColor&&`
    background-color: var(--${a.bgColor});
  `}
`;a.s(["default",0,c])},6077,(a,b,c)=>{b.exports=a.x("prismic-reactjs",()=>require("prismic-reactjs"))},94905,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(46283),f=a.i(27899),g=a.i(6077),h=a.i(93631),i=a.i(19608),j=a.i(45491),k=b([i]);[i]=k.then?(await k)():k;let l=(0,e.default)(j.default).withConfig({displayName:"TextBlock__StyledLink",componentId:"sc-facd1adf-0"})`
  color: var(--gold);
  text-decoration: none;
  position: relative;
  transition: color 300ms ease;

  &::after {
    content: "";
    width: 100%;
    height: 2px;
    background: var(--brand-black);
    position: absolute;
    left: 0;
    bottom: -1px;
    transition: color 300ms ease;
  }

  ${(0,h.hover)(`
    color: var(--brand-black);

    &::after {
      color: var(--gold);
    }
  `)}
`,m=(a,b,c)=>(0,d.jsx)(l,{href:(0,i.linkResolver)(b.data),children:c},`${b.data.link_type}${b.start}`),n=({content:a,...b})=>a?(0,d.jsx)(g.RichText,{render:a,serializeHyperlink:m,...b}):null;n.propTypes={content:f.default.array},a.s(["default",0,n]),c()}catch(a){c(a)}},!1),86011,a=>{"use strict";var b=a.i(8171);a.i(27669),a.s(["default",0,()=>(0,b.jsx)("svg",{viewBox:"0 0 19 36",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,b.jsx)("path",{d:"M0 20.102C5.979 13.784 18.15.919 19 0l-6.378 15.938H19L1.329 35.753l5.846-17.23L0 20.101z",fill:"currentColor"})})])},75305,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(51176),g=a.i(43124),h=a.i(46283),i=a.i(49933),j=a.i(74852),k=a.i(19608),l=a.i(93631),m=a.i(8444),n=a.i(86011),o=a.i(45491),p=b([k]);[k]=p.then?(await p)():p;let q=h.default.div.withConfig({displayName:"MarqueeBlock__Wrapper",componentId:"sc-58b4aa9e-0"})`
  overflow: hidden;
  height: 188px;
  position: relative;
  max-width: 100%;
  width: 100%;

  ${j.default.below(l.bp.desktopSm,`
    height: 150px;
  `)}

  ${j.default.below(l.bp.portrait,`
    height: 105px;
  `)}
`,r=(0,h.default)(o.default).withConfig({displayName:"MarqueeBlock__CTA",componentId:"sc-58b4aa9e-1"})`
  display: inline-block;
  padding: 42px;
  text-align: center;
  color: var(--gold);
  text-transform: uppercase;
  white-space: nowrap;

  ${j.default.below(l.bp.desktopSm,`
    padding: 22px;
  `)}

  ${j.default.below(l.bp.portrait,`
    padding: 8px 22px 0;
  `)}

  svg {
    display: block;
    max-width: 19px;
    margin: auto auto 10px;

    ${j.default.below(l.bp.portrait,`
       margin-bottom: 0;
    `)}
  }
`,s=h.default.div.withConfig({displayName:"MarqueeBlock__Item",componentId:"sc-58b4aa9e-2"})`
  display: block;
  position: absolute;
  left: 100%;
  top: 16px;

  span {
    white-space: nowrap;
    line-height: 1;
  }
`,t=(0,h.default)(m.OneSixty).withConfig({displayName:"MarqueeBlock__StyledOneSixty",componentId:"sc-58b4aa9e-3"})`
  ${j.default.below(l.bp.mobile,`
    font-size: ${(0,i.rem)(75)};
  `)}
`;a.s(["default",0,({content:a,marqueeID:b})=>{let c=(0,e.useRef)(),h=(0,e.useCallback)(()=>{g.default.getById(`${b}-marquee-scroll-trigger`)&&g.default.getById(`${b}-marquee-scroll-trigger`).kill(),c.current&&c.current.kill()},[b,c]),i=(0,e.useCallback)(a=>{if(!a)return;f.default.registerPlugin(g.default);let d=a.querySelectorAll(".marquee-item");g.default.addEventListener("refresh",()=>{f.default.set(d,{x:0}),h();let e=0,i=0;d.length&&d.forEach((a,b)=>{let c=f.default.getProperty(a,"width");b>0&&(f.default.set(a,{x:-1*(c+i)}),i+=c),e+=c}),c.current=f.default.to(d,{x:`-=${e}`,repeat:-1,duration:18,ease:"none",modifiers:{x:f.default.utils.unitize(a=>f.default.utils.wrap(-e,0,a))}}),g.default.create({trigger:a,animation:c.current,start:"top bottom",end:"bottom top",id:`${b}-marquee-scroll-trigger`})})},[h,b]),j=()=>{c.current&&c.current.pause()},l=()=>{c.current&&(c.current.play(),f.default.fromTo(c.current,{timeScale:0},{timeScale:1,ease:"power1.in"}))};return(0,e.useEffect)(()=>()=>{h()},[h]),(0,d.jsxs)(q,{ref:i,children:[a?.first_text_content?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsx)(t,{children:a?.first_text_content})}):null,a?.link?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsxs)(r,{onMouseEnter:j,onMouseLeave:l,href:(0,k.linkResolver)(a?.link),children:[(0,d.jsx)(n.default,{}),a?.link_text]})}):null,a?.second_text_content?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsx)(t,{children:a?.second_text_content})}):null,a?.link?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsxs)(r,{onMouseEnter:j,onMouseLeave:l,href:(0,k.linkResolver)(a?.link),children:[(0,d.jsx)(n.default,{}),a?.link_text]})}):null,a?.third_text_content?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsx)(t,{children:a?.third_text_content})}):null,a?.link?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsxs)(r,{onMouseEnter:j,onMouseLeave:l,href:(0,k.linkResolver)(a?.link),children:[(0,d.jsx)(n.default,{}),a?.link_text]})}):null]})}]),c()}catch(a){c(a)}},!1),5235,(a,b,c)=>{b.exports=a.x("gsap/dist/Draggable.js",()=>require("gsap/dist/Draggable.js"))},92802,(a,b,c)=>{b.exports=a.x("gsap/dist/InertiaPlugin.js",()=>require("gsap/dist/InertiaPlugin.js"))},40576,a=>{"use strict";var b=a.i(8171);a.i(27669);var c=a.i(27899),d=a.i(46283),e=a.i(93631),f=a.i(74852),g=a.i(68178),h=a.i(8444),i=a.i(10424);let j=d.keyframes`
  0% {
    transform: translateX(0);
  }

  100% {
    transform: translateX(-50%);
  }
`,k=(0,d.default)(i.default).withConfig({displayName:"BlackLogoGrid__Wrapper",componentId:"sc-99f4a700-0"})`
  --title-width: 400px;

  position: relative;
  padding: ${a=>a.title?"372px 0 308px":"380px 0"};
  color: var(--brand-white);
  overflow: hidden;

  ${a=>f.default.below(e.bp.desktopSm,`
    --title-width: 280px;
    padding: ${a.title?"300px 0 230px":"320px 0"};
  `)}

  ${a=>f.default.below(e.bp.portrait,`
    --title-width: 170px;
    padding: ${a.title?"220px 0 144px":"220px 0"};
  `)}
`,l=d.default.div.withConfig({displayName:"BlackLogoGrid__LogosContainer",componentId:"sc-99f4a700-1"})`
  position: absolute;
  top: ${a=>a.title?"180px":"90px"};
  left: 0;

  ${f.default.below(e.bp.portrait,`
    top: ${a=>a.title?"136px":"0"};
  `)}
`,m=d.default.div.withConfig({displayName:"BlackLogoGrid__LogosRow",componentId:"sc-99f4a700-2"})`
  font-size: 0;
  display: flex;
  flex-wrap: nowrap;
  margin: 10px 0;
  animation: 32s ${j} infinite linear;

  &:nth-of-type(even) {
    animation-direction: reverse;
  }

  img { min-width: calc(var(--title-width) * 6.1); }

`,n=(0,d.default)(h.OneSixty).withConfig({displayName:"BlackLogoGrid__Title",componentId:"sc-99f4a700-3"})`
  position: relative;
  z-index: 1;
  line-height: 1;
  width: var(--title-width);
  max-width: var(--title-width);

  &::before {
    position: absolute;
    top: 0;
    left: 0;
    z-index: -1;
    width: 100%;
    height: 100%;
    background-color: var(--brand-black);
    box-shadow: 0 0 10px 10px var(--brand-black);
    content: "";
  }

  ${f.default.below(e.bp.mobile,`
    max-width: 200px;
  `)}
`,o=({title:a,logoRowOne:c,logoRowTwo:d,logoRowThree:e,logoRowFour:f})=>(0,b.jsxs)(k,{bgColor:"brand-black",title:a,children:[a?(0,b.jsx)(g.default,{children:(0,b.jsx)(n,{as:"h1",children:a})}):null,(0,b.jsxs)(l,{title:a,children:[c?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:c.url,alt:c.alt}),(0,b.jsx)("img",{src:c.url,alt:"","aria-hidden":"true"})]}):null,d?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:d.url,alt:d.alt}),(0,b.jsx)("img",{src:d.url,alt:"","aria-hidden":"true"})]}):null,e?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:e.url,alt:e.alt}),(0,b.jsx)("img",{src:e.url,alt:"","aria-hidden":"true"})]}):null,f?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:f.url,alt:f.alt}),(0,b.jsx)("img",{src:f.url,alt:"","aria-hidden":"true"})]}):null]})]});o.propTypes={title:c.default.string,logoRowOne:c.default.object,logoRowTwo:c.default.object,logoRowThree:c.default.object,logoRowFour:c.default.object},a.s(["default",0,o])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__1fe98008._.js.map
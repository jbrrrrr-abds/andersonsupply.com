module.exports=[50764,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(49933),i=a.i(19608),j=a.i(35688),k=a.i(93631),l=a.i(8444),m=a.i(64472),n=a.i(15935),o=a.i(31164),p=b([i]);[i]=p.then?(await p)():p;let q=f.default.div.withConfig({displayName:"HeroCarousel__Wrapper",componentId:"sc-38a18a8b-0"})`
  position: relative;
  margin: auto;
  background-color: var(--brand-black);
`,r=f.default.div.withConfig({displayName:"HeroCarousel__SlideWrap",componentId:"sc-38a18a8b-1"})`
  position: relative;
  z-index: 1;
  color: var(--brand-white);
  text-align: center;

  &::before {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 2;
    width: 100%;
    height: 100%;
    background: linear-gradient(180deg, rgb(0 0 0 / 62%) 0%, rgb(0 0 0 / 0%) 100%);
    content: "";
  }
`,s=f.default.div.withConfig({displayName:"HeroCarousel__Content",componentId:"sc-38a18a8b-2"})`
  position: relative;
  z-index: 9;
  padding: 386px 0;

  ${g.default.below(k.bp.desktopLg,`
    padding: 290px 0;
  `)}

  ${g.default.below(k.bp.mobile,`
    padding: 195px 0;
  `)}
`,t=f.default.nav.withConfig({displayName:"HeroCarousel__CarouselNavigation",componentId:"sc-38a18a8b-3"})`
  position: absolute;
  bottom: 50px;
  z-index: 9;
  display: flex;
  align-items: center;
  left: var(--container-gutter);
  color: var(--brand-white);
`,u=(0,f.default)(n.default).withConfig({displayName:"HeroCarousel__ArrowList",componentId:"sc-38a18a8b-4"})`
  display: flex;
  justify-content: space-between;
  width: 92px;
  margin-right: 30px;
`,v=(0,f.default)(j.default.Dots).withConfig({displayName:"HeroCarousel__DotList",componentId:"sc-38a18a8b-5"})`
  margin-top: -7px;
`,w=(0,f.default)(l.Ninety).withConfig({displayName:"HeroCarousel__Headline",componentId:"sc-38a18a8b-6"})`
  ${g.default.below(k.bp.mobile,`
    font-size: ${(0,h.rem)(40)};
  `)}
`,x=({slides:a=[]})=>{let{flickity:b,setFlickityIndex:c,flickityIndex:e}=(0,j.useCarousel)();return a?.length<1?null:(0,d.jsxs)(q,{children:[(0,d.jsxs)(t,{"aria-label":"Hero Carousel",children:[(0,d.jsxs)(u,{children:[(0,d.jsx)("li",{children:(0,d.jsx)(j.default.Button,{slideCount:a.length,currentIndex:e,handleClick:c,action:"prev",color:"brand-white"})}),(0,d.jsx)("li",{children:(0,d.jsx)(j.default.Button,{slideCount:a.length,currentIndex:e,handleClick:c,isLeft:!0,action:"next",color:"brand-white"})})]}),(0,d.jsx)(v,{isDark:!0,slides:a,currentIndex:e,handleClick:c})]}),(0,d.jsx)(j.default,{ref:b,children:a.map((a,b)=>(0,d.jsx)(j.default.Slide,{children:(0,d.jsxs)(r,{children:[(0,d.jsx)(o.default,{src:`${a.slide_image.url}&w=1280&h=720&fit=crop&q=85&f=center`,alt:a.slide_image.alt?a.slide_image.alt:""}),(0,d.jsxs)(s,{children:[(0,d.jsx)(w,{children:a.slide_title}),(0,d.jsx)(m.default,{href:(0,i.linkResolver)(a.slide_link_url),large:!0,bgcolor:"brand-white",hasmargin:!0,children:a.slide_link_text})]})]})},b))})]})};x.propTypes={slides:e.default.array},a.s(["default",0,x]),c()}catch(a){c(a)}},!1),68988,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(27899),g=a.i(46283),h=a.i(74852),i=a.i(49933),j=a.i(51176),k=a.i(43124),l=a.i(93631),m=a.i(19608),n=a.i(10424),o=a.i(64472),p=b([m]);[m]=p.then?(await p)():p;let q=(0,g.default)(n.default).withConfig({displayName:"Work__StyledSection",componentId:"sc-5453eded-0"})`
  position: relative;
  padding: 0;
  text-align: center;
  overflow: hidden;
`,r=(0,g.default)(o.default).withConfig({displayName:"Work__HomeWorkButton",componentId:"sc-5453eded-1"})`
  ${(0,i.position)("absolute",0,0,0,0)};
  margin: auto;
  height: 40px;
  width: 250px;
  text-align: center;
  z-index: 2;
`,s=g.default.div.withConfig({displayName:"Work__ScrollBG",componentId:"sc-5453eded-2"})`
  z-index: 1;
  white-space: nowrap;
  width: 250vw;
  position: relative;
  font-size: 0;

  img {
    width: 50%;
    position: relative;
    display: inline-block;
  }
`,t=g.default.img.withConfig({displayName:"Work__DesktopImage",componentId:"sc-5453eded-3"})`
  ${h.default.below(l.bp.mobile,`
    display: none;
  `)}
`,u=g.default.img.withConfig({displayName:"Work__MobileImage",componentId:"sc-5453eded-4"})`
  ${h.default.above(l.bp.mobile,`
    display: none;
  `)}
`,v=({link:a,linkText:b,image:c,mobileImage:f})=>{let g=(0,e.useRef)(),h=(0,e.useRef)(1),i=(0,e.useCallback)(a=>{a&&(j.default.registerPlugin(k.default),g.current=j.default.to(a,{xPercent:-50,duration:30,ease:"none",repeat:-1,onReverseComplete(){this.totalTime(100*this.duration()+this.rawTime())}}),k.default.create({trigger:a,id:"home-work",start:"top bottom",end:"bottom top",animation:g.current,toggleActions:"play pause resume reset",onUpdate(a){h.current!==a.direction&&(j.default.to(g.current,{duration:4,ease:"slow(0.1, 0.7, false)",overwrite:"auto",timeScale:a.direction}),h.current=a.direction)}}))},[]);if((0,e.useEffect)(()=>()=>{k.default.getById("home-work")&&k.default.getById("home-work").kill(),g.current&&g.current.kill()},[]),c)return(0,d.jsxs)(q,{bgColor:"gold",children:[a?(0,d.jsx)(r,{isdark:!0,bgcolor:"brand-black",large:!0,href:(0,m.linkResolver)(a),children:b}):null,(0,d.jsxs)(s,{ref:i,children:[(0,d.jsx)(t,{src:`${c?.url}&w=1652&h=678&fit=crop&q=85&f=center`,alt:c?.alt}),(0,d.jsx)(t,{"aria-hidden":"true",src:`${c.url}&w=1652&h=678&fit=crop&q=85&f=center`,alt:""}),(0,d.jsx)(u,{src:`${f?.url}&w=826&h=340&fit=crop&q=85&f=center`,alt:f?.alt}),(0,d.jsx)(u,{"aria-hidden":"true",src:`${f?.url}&w=826&h=340&fit=crop&q=85&f=center`,alt:""})]})]})};v.propTypes={link:f.default.object,linkText:f.default.string,image:f.default.object,mobileImage:f.default.object},a.s(["default",0,v]),c()}catch(a){c(a)}},!1),43995,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(10424),h=a.i(68178),i=a.i(24463),j=b([i]);[i]=j.then?(await j)():j;let k=(0,f.default)(g.default).withConfig({displayName:"Services__StyledSection",componentId:"sc-a2ea65ee-0"})`
  position: relative;
  z-index: 1;
  color: var(--white);

  h2 {
    color: var(--brand-white);
    position: relative;
    z-index: 2;
  }
`,l=({title:a,services:b=[]})=>(0,d.jsx)(k,{hasPadding:!0,bgColor:"brand-black",children:(0,d.jsxs)(h.default,{children:[a?(0,d.jsx)("h2",{children:a}):null,(0,d.jsx)(i.default,{services:b})]})});l.propTypes={title:e.default.string,services:e.default.array},a.s(["default",0,l]),c()}catch(a){c(a)}},!1),95147,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(27899),g=a.i(51176),h=a.i(43124),i=a.i(46283),j=a.i(74852),k=a.i(49933),l=a.i(19608),m=a.i(93631),n=a.i(10424),o=a.i(68178),p=a.i(760),q=a.i(15935),r=a.i(6912),s=a.i(64472),t=a.i(8444),u=a.i(94905),v=b([l,u]);[l,u]=v.then?(await v)():v;let w=(0,i.default)(n.default).withConfig({displayName:"Kiss__StyledSection",componentId:"sc-95b7061f-0"})`
  text-align: center;

  h2 {
    margin-bottom: 58px;
    text-align: center;
  }

  article {
    text-align: left;
  }
`,x=(0,i.default)(p.default).withConfig({displayName:"Kiss__StyledGrid",componentId:"sc-95b7061f-1"})`
  grid-template-columns: repeat(3, 1fr);
  gap: 165px;

  li {
    visibility: hidden;
  }

  img { border-radius: 50%; }

  ${j.default.between(m.bp.desktop,m.bp.desktopLg,`
    grid-gap: 124px;
  `)}

  ${j.default.between(m.bp.laptopSm,m.bp.desktop,`
    grid-gap: 82px;
  `)}

  ${j.default.below(m.bp.laptopSm,`
    grid-gap: 30px;
  `)}

  ${j.default.below(m.bp.tablet,`
    grid-template-columns: 1fr;
    max-width: 540px;
    margin: auto;
  `)}
`,y=i.default.span.withConfig({displayName:"Kiss__ItemTitle",componentId:"sc-95b7061f-2"})`
  display: block;
  margin-top: 60px;
  font-size: ${(0,k.rem)(20)};
  font-weight: 700;
  text-transform: uppercase;

  ${j.default.below(m.bp.desktop,`
    margin-top: 45px;
  `)}
`,z=(0,i.default)(s.default).withConfig({displayName:"Kiss__StyledButton",componentId:"sc-95b7061f-3"})`
  display: inline-block;
  margin: 100px auto auto;

  ${j.default.below(m.bp.desktopLg,`
    margin: 75px auto auto;
  `)}

  ${j.default.below(m.bp.desktop,`
    margin: 50px auto auto;
  `)}

  ${(0,m.hover)(`
    background-color: var(--gold);
  `)}
`,A=i.default.div.withConfig({displayName:"Kiss__ImageWrap",componentId:"sc-95b7061f-4"})`
  position: relative;
`,B=(0,i.default)(t.OneSixty).withConfig({displayName:"Kiss__Number",componentId:"sc-95b7061f-5"})`
  position: absolute;
  top: 50%;
  left: 50%;
  color: var(--white);
  transform: translate(-50%, -50%);
`,C=({stepItems:a=[],title:b,linkUrl:c,linkText:f})=>{let i=(0,e.useCallback)(a=>{if(!a)return;g.default.registerPlugin(h.default);let b=a.querySelectorAll(".step");b.length>0&&h.default.batch(b,{onEnter:a=>g.default.from(a,{duration:2,autoAlpha:0,y:70,stagger:{each:.25},overwrite:!0,ease:"power3"}),id:"kiss-trigger",start:"top bottom-=70",end:"+=0",once:!0})},[]);return(0,e.useEffect)(()=>()=>{h.default.getById("kiss-trigger")&&h.default.getById("kiss-trigger").kill()},[]),(0,d.jsxs)(w,{as:o.default,hasPadding:!0,children:[(0,d.jsx)("h2",{children:b}),a?(0,d.jsx)(x,{as:q.default,ref:i,children:a.map((a,b)=>(0,d.jsx)("li",{className:"step",children:(0,d.jsxs)("article",{children:[(0,d.jsxs)(A,{children:[(0,d.jsx)(r.default,{width:450,height:300,src:`${a?.image?.url}&w=450&h=300&fit=crop&q=85&f=center`,alt:""}),(0,d.jsx)(B,{children:b+1})]}),(0,d.jsx)(y,{children:a.title}),(0,d.jsx)(u.default,{content:a.description})]})},b))}):null,c?(0,d.jsx)(z,{isdark:!0,large:!0,bgcolor:"brand-black",href:(0,l.linkResolver)(c),children:f}):null]})};C.propTypes={stepItems:f.default.array,title:f.default.string,linkUrl:f.default.object,linkText:f.default.string},a.s(["default",0,C]),c()}catch(a){c(a)}},!1),4901,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(93631),i=a.i(10424),j=a.i(68178),k=a.i(27129),l=a.i(94905),m=b([k,l]);[k,l]=m.then?(await m)():m;let n=(0,f.default)(i.default).withConfig({displayName:"Video__StyledSection",componentId:"sc-a001ef75-0"})`
  padding: var(--spacing) 0 46px;
`,o=f.default.div.withConfig({displayName:"Video__Content",componentId:"sc-a001ef75-1"})`
  max-width: 500px;
  margin: 88px auto auto;
  text-align: center;

  p:last-of-type { margin-bottom: 0; }

  ${g.default.below(h.bp.desktop,`
    margin-top: 66px;
  `)}

  ${g.default.below(h.bp.laptopSm,`
    margin-top: 44px;
  `)}
`,p=({title:a,description:b,topText:c,bottomText:e,video:f,videoId:g})=>(0,d.jsx)(n,{bgColor:"brand-white",children:(0,d.jsxs)(j.default,{children:[(0,d.jsx)(k.default,{topText:c,bottomText:e,video:f,videoId:g}),a||b?(0,d.jsxs)(o,{children:[a?(0,d.jsx)("h2",{children:a}):null,b?(0,d.jsx)(l.default,{content:b}):null]}):null]})});p.propTypes={title:e.default.string,description:e.default.array,topText:e.default.string,bottomText:e.default.string,video:e.default.object,videoId:e.default.string},a.s(["default",0,p]),c()}catch(a){c(a)}},!1),28386,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(19608),i=a.i(93631),j=a.i(10424),k=a.i(68178),l=a.i(760),m=a.i(15749),n=a.i(64472),o=a.i(94905),p=b([h,m,o]);[h,m,o]=p.then?(await p)():p;let q=(0,f.default)(l.default).withConfig({displayName:"TwoColWithImage__StyledGrid",componentId:"sc-ec4a8732-0"})`
  max-width: 1560px;
  margin: auto;

  ${g.default.below(i.bp.desktopSm,`
    grid-gap: 40px;
  `)}

  ${g.default.above(i.bp.laptopSm,`
    grid-template-columns: 1fr 1.4fr;
    align-items: center;
  `)}

  ${g.default.below(i.bp.laptopSm,`
    grid-row-gap: 52px;
    text-align: center;
  `)}
`,r=f.default.div.withConfig({displayName:"TwoColWithImage__Content",componentId:"sc-ec4a8732-1"})`
  order: 1;
  max-width: 440px;

  ${g.default.below(i.bp.laptopSm,`
    order: 2;
    margin: auto;
  `)}
`,s=(0,f.default)(m.default).withConfig({displayName:"TwoColWithImage__Image",componentId:"sc-ec4a8732-2"})`
  order: 2;

  ${g.default.below(i.bp.laptopSm,`
    order: 1;
  `)}
`,t=(0,f.default)(n.default).withConfig({displayName:"TwoColWithImage__StyledButton",componentId:"sc-ec4a8732-3"})`
  margin-top: 14px;
`,u=({headline:a,description:b,image:c,link:e,linkText:f})=>(0,d.jsx)(j.default,{hasPadding:!0,bgColor:"brand-white",children:(0,d.jsx)(k.default,{children:(0,d.jsxs)(q,{children:[(0,d.jsxs)(r,{children:[a?(0,d.jsx)("h2",{children:a}):null,b?(0,d.jsx)(o.default,{content:b}):null,e?(0,d.jsx)(t,{href:(0,h.linkResolver)(e),isdark:!0,bgcolor:"gold",large:!0,children:f}):null]}),c?(0,d.jsx)(s,{width:897,height:585,src:`${c.url}?w=897&h=585&fit=fill&q=85&f=center`,alt:c.alt}):null]})})});u.propTypes={headline:e.default.string,description:e.default.array,image:e.default.object,link:e.default.object,linkText:e.default.string},a.s(["default",0,u]),c()}catch(a){c(a)}},!1),58389,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(28386),g=b([f]);[f]=g.then?(await g)():g;let h=({title:a,description:b,link:c,linkText:e,image:g})=>(0,d.jsx)(f.default,{headline:a,description:b,link:c,linkText:e,image:g});h.propTypes={title:e.default.string,description:e.default.array,link:e.default.object,linkText:e.default.string,image:e.default.object},a.s(["default",0,h]),c()}catch(a){c(a)}},!1),95532,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(65762),f=a.i(47659),g=a.i(50764),h=a.i(68988),i=a.i(43995),j=a.i(95147),k=a.i(60509),l=a.i(4901),m=a.i(58389),n=a.i(75305),o=a.i(9959),p=a.i(91169),q=a.i(10512),r=b([f,g,h,i,j,k,l,m,n,o,p]);async function s({preview:a,previewData:b}){let c=(0,f.createClient)({previewData:b});return{props:{page:await c.getSingle("home",{fetchLinks:["services_navigation.services","services.link_url","testimonial.quote","testimonial.quotee","marquee.first_text_content","marquee.second_text_content","marquee.third_text_content","marquee.link","marquee.link_text"]})||{}}}}[f,g,h,i,j,k,l,m,n,o,p]=r.then?(await r)():r,a.s(["default",0,({page:a})=>{let{modalOpen:b}=(0,p.useModal)();if(!a)return null;let{data:c}=a;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.Helmet,{meta:[{name:"description",content:c?.page_description},{property:"og:title",content:c?.page_title},{property:"og:description",content:c?.page_description},{property:"og:image",content:`${c?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:image",content:`${c?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:title",content:c?.page_title},{name:"twitter:description",content:c?.page_description}]}),(0,d.jsxs)("main",{children:[(0,d.jsx)(g.default,{slides:c?.hero_carousel}),(0,d.jsx)(h.default,{link:c?.work_link,linkText:c?.work_link_text,image:c?.work_image,mobileImage:c?.work_mobile_image}),(0,d.jsx)(i.default,{title:c?.services_title,services:c?.services?.data?.services}),(0,d.jsx)(j.default,{title:c?.three_column_title,stepItems:c?.three_column_grid,linkUrl:c?.three_column_link,linkText:c?.three_column_link_text}),(0,d.jsx)(k.default,{title:c?.testimonials_title,testimonials:c?.testimonials}),(0,d.jsx)(l.default,{title:c?.video_title,description:c?.video_description,topText:c?.video_top_text,bottomText:c?.video_bottom_text,video:c?.video,videoId:c?.video_id}),(0,d.jsx)(m.default,{title:c?.two_column_title,description:c?.two_column_description,link:c?.two_column_link,linkText:c?.two_column_link_text,image:c?.two_column_image}),(0,d.jsx)(n.default,{marqueeID:a?.id,content:c?.marquee?.data})]}),(0,d.jsx)(o.default,{children:(0,d.jsx)(q.default,{youTubeID:b})})]})},"getStaticProps",()=>s]),c()}catch(a){c(a)}},!1),95562,a=>a.a(async(b,c)=>{try{var d=a.i(76164),e=a.i(23503),f=a.i(92188),g=a.i(67684),h=a.i(76695),i=a.i(95532),j=a.i(76441),k=b([h,i]);[h,i]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/index",pathname:"/",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/index",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_bc3772e0._.js.map
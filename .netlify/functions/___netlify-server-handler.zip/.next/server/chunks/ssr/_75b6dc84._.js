module.exports=[82181,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(51176),i=a.i(21428),j=a.i(92593),k=a.i(93631),l=a.i(91169),m=a.i(10424),n=a.i(68178),o=a.i(8444),p=a.i(72253),q=a.i(6912),r=a.i(94905),s=b([l,r]);[l,r]=s.then?(await s)():s;let t=(0,f.default)(m.default).withConfig({displayName:"Hero__StyledSection",componentId:"sc-b7afbec3-0"})`
  position: relative;
  z-index: 1;
  padding: 320px 0 var(--spacing);
  color: var(--brand-white);

  h1 {
    margin-bottom: 36px;
    color: var(--gold);
  }

  p {
    max-width: 500px;

    &:last-of-type {
      margin-bottom: 0;
    }
  }

  ${g.default.below(k.bp.desktopSm,`
    padding-top: 240px;
  `)}

  ${g.default.below(k.bp.laptopSm,`
    padding-bottom: 0;
  `)}

  ${g.default.below(k.bp.portrait,`
    padding-top: 160px;
  `)}
`,u=f.default.h2.withConfig({displayName:"Hero__JumboText",componentId:"sc-b7afbec3-1"})`
  max-width: 770px;
`,v=f.default.div.withConfig({displayName:"Hero__Image",componentId:"sc-b7afbec3-2"})`
  position: relative;
  width: 967px;
  height: 580px;
  margin: auto;

  img {
    z-index: -1;
    opacity: .75;
    filter: grayscale(100%);
  }

  ${g.default.above(k.bp.laptopSm,`
    position: absolute;
    right: var(--container-gutter);
    bottom: 114px;
  `)}

  ${g.default.below(k.bp.desktop,`
    width: 725px;
    height: 435px;
  `)}

  ${g.default.below(k.bp.laptopSm,`
    width: auto;
    height: auto;
    margin-top: 75px;
  `)}
`,w=(0,f.default)(p.default).withConfig({displayName:"Hero__Button",componentId:"sc-b7afbec3-3"})`
  && {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
  }
`,x=f.default.div.withConfig({displayName:"Hero__Arrow",componentId:"sc-b7afbec3-4"})`
  margin-top: 80px;

  button {
    cursor: pointer;
    transition: color 300ms ease;
    color: currentcolor;
    padding: 0 10px;
    margin-left: -10px;

    ${(0,k.hover)(`
      color: var(--gold);
    `)}
  }

  ${g.default.below(k.bp.laptopSm,`
    display: none;
  `)}
`,y=f.default.div.withConfig({displayName:"Hero__ScrollTarget",componentId:"sc-b7afbec3-5"})`
  position: absolute;
  bottom: 0;
  left: 0;
`,z=f.default.div.withConfig({displayName:"Hero__Content",componentId:"sc-b7afbec3-6"})`
  padding-left: var(--customer-container-gutter);
`,A=({title:a,subTitle:b,description:c,image:e,videoId:f})=>{let{toggleModal:g}=(0,l.useModal)();return(0,d.jsxs)(t,{bgColor:"brand-black",children:[(0,d.jsx)(n.default,{children:(0,d.jsxs)(z,{children:[a?(0,d.jsx)("h1",{children:a}):null,b?(0,d.jsx)(u,{as:o.Ninety,children:b}):null,c?(0,d.jsx)(r.default,{content:c}):null,(0,d.jsx)(x,{children:(0,d.jsx)(j.default,{onClick:()=>{h.default.registerPlugin(i.default),h.default.to(window,{duration:.4,ease:"power2.inOut",scrollTo:"#our-process"})},"aria-label":"Go to next section",children:(0,d.jsx)("svg",{width:"16",height:"36",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,d.jsx)("path",{d:"M16 27.5l-1.41-1.41L9 31.67V0H7v31.67l-5.58-5.59L0 27.5l8 8 8-8z",fill:"currentColor"})})})})]})}),(0,d.jsxs)(v,{alt:"",children:[e?(0,d.jsx)(q.default,{src:`${e.url}&w=967&h=580&fit=crop&q=85&fm=pjpg`,alt:e.alt,width:967,height:580}):null,f?(0,d.jsx)(w,{onClick:()=>{g(f)},"aria-label":"Play video"}):null]}),(0,d.jsx)(y,{id:"our-process"})]})};A.propTypes={title:e.default.string,subTitle:e.default.string,description:e.default.array,image:e.default.object,videoId:e.default.string},a.s(["default",0,A]),c()}catch(a){c(a)}},!1),22124,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(74852),g=a.i(46283),h=a.i(93631),i=a.i(10424),j=a.i(68178),k=a.i(94905),l=b([k]);[k]=l.then?(await l)():l;let m=(0,g.default)(i.default).withConfig({displayName:"Intro__StyledSection",componentId:"sc-f28a5532-0"})`
  position: relative;
  overflow: hidden;

  p {
    max-width: 712px;

    &:last-of-type {
      margin-bottom: 0;
    }
  }

  img {
    position: absolute;
    top: 0;
    right: 0;
    z-index: -1;
    width: 718px;
    height: 517px;

    ${f.default.below(h.bp.laptopSm,`
      width: 360px;
      height: 258px;
    `)}

    ${f.default.below(h.bp.mobile,`
      top: unset;
      bottom: 0;
    `)}
  }

  ${f.default.below(h.bp.mobile,`
    padding-bottom: 165px;
  `)}
`,n=g.default.div.withConfig({displayName:"Intro__Content",componentId:"sc-f28a5532-1"})`
  padding-left: var(--customer-container-gutter);
`,o=({title:a,description:b,graphic:c})=>c?(0,d.jsx)(m,{hasPadding:!0,children:(0,d.jsxs)(j.default,{children:[(0,d.jsxs)(n,{children:[a?(0,d.jsx)("h2",{children:a}):null,b?(0,d.jsx)(k.default,{content:b}):null]}),c?(0,d.jsx)("img",{src:c.url,alt:c.alt}):null]})}):null;o.propTypes={title:e.default.string,description:e.default.array,graphic:e.default.object},a.s(["default",0,o]),c()}catch(a){c(a)}},!1),18175,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(27899),g=a.i(46283),h=a.i(74852),i=a.i(51176),j=a.i(43124),k=a.i(19608),l=a.i(93631),m=a.i(15935),n=a.i(760),o=a.i(8444),p=a.i(64472),q=a.i(15749),r=a.i(94905),s=b([k,q,r]);[k,q,r]=s.then?(await s)():s;let t=(0,g.default)(n.default).withConfig({displayName:"Steps__StepGrid",componentId:"sc-d7aff339-0"})`
  grid-template-columns: repeat(2, 1fr);
  gap: 0;

  &:nth-of-type(odd) {
    grid-template-areas: "content image";
    background-color: var(--brand-white);
  }

  &:nth-of-type(even) {
    grid-template-areas: "image content";
    color: var(--brand-white);
    background-color: var(--brand-black);
  }

  ${h.default.below(l.bp.laptopSm,`
    grid-template-columns: 1fr;

    && {
      grid-template-areas: "content""image";
    }
  `)}
`,u=g.default.div.withConfig({displayName:"Steps__StepInfo",componentId:"sc-d7aff339-1"})`
  display: flex;
  align-items: center;
  justify-content: center;
  grid-area: content;
  padding: 350px 0 210px;

  p:last-of-type { margin-bottom: 0; }

  ${h.default.below(l.bp.laptopSm,`
    padding: 262px 0 158px;
  `)}

  ${h.default.below(l.bp.laptopSm,`
    padding: 175px var(--container-gutter) 105px;
  `)}
`,v=g.default.article.withConfig({displayName:"Steps__Article",componentId:"sc-d7aff339-2"})`
  position: relative;
  z-index: 1;

  ${h.default.above(l.bp.laptopSm,`
    max-width: 536px;
  `)}
`,w=g.default.span.withConfig({displayName:"Steps__StepNumber",componentId:"sc-d7aff339-3"})`
  position: absolute;
  top: -146px;
  left: -120px;
  z-index: -1;
  line-height: 1;
  color: var(--gold);

  ${h.default.below(l.bp.desktopLg,`
    left: -90px;
  `)}

  ${h.default.below(l.bp.desktop,`
    left: -60px;
  `)}

  ${h.default.below(l.bp.desktopSm,`
    top: -110px;
    left: 0;
  `)}
`,x=(0,g.default)(q.default).withConfig({displayName:"Steps__StepImage",componentId:"sc-d7aff339-4"})`
  grid-area: image;

  ${h.default.above(l.bp.laptopSm,`
    img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  `)}
`,y=({steps:a=[]})=>{let b=(0,e.useCallback)(a=>{a&&(i.default.registerPlugin(j.default),a.querySelectorAll(".step-number").forEach((a,b)=>{j.default.create({trigger:a,start:"top 90%",end:"+=0",id:`steps-${b}`,once:!0,animation:i.default.from(a,{yPercent:30,autoAlpha:0,duration:1,ease:"circ.out"})})}))},[]);return(0,e.useEffect)(()=>()=>{a.length&&a.forEach((a,b)=>{j.default.getById(`steps-${b}`)&&j.default.getById(`steps-${b}`).kill()})},[a]),(0,d.jsx)("section",{ref:b,children:(0,d.jsx)(m.default,{children:a.map((a,b)=>{var c;return(0,d.jsxs)(t,{as:"li",children:[(0,d.jsx)(u,{children:(0,d.jsxs)(v,{children:[(0,d.jsx)(w,{className:"step-number",as:o.TwoTen,children:(c=b+1)&&!((c&&c)>9)?`0${c}`:c}),a.title?(0,d.jsx)("h2",{children:a.title}):null,a.description?(0,d.jsx)(r.default,{content:a.description}):null,a.link.url?(0,d.jsx)(p.default,{href:(0,k.linkResolver)(a.link),isdark:!0,large:!0,hasmargin:!0,bgcolor:"gold",children:a.link_text}):null]})}),a.image?(0,d.jsx)(x,{src:`${a.image.url}w=900&h=720&fit=crop&q=85&fm=pjpg`,alt:a.image.alt}):null]},b)})})})};y.propTypes={steps:f.default.array},a.s(["default",0,y]),c()}catch(a){c(a)}},!1),10919,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(49933),h=a.i(74852),i=a.i(93631),j=a.i(19608),k=a.i(10424),l=a.i(68178),m=a.i(760),n=a.i(15749),o=a.i(8444),p=a.i(45491),q=a.i(86011),r=a.i(94905),s=b([j,n,r]);[j,n,r]=s.then?(await s)():s;let t=(0,f.default)(k.default).withConfig({displayName:"ImageGrid__StyledSection",componentId:"sc-a4bebbc4-0"})`
  text-align: center;

  p {
    max-width: 827px;
    margin: auto;
  }
`,u=(0,f.default)(m.default).withConfig({displayName:"ImageGrid__StyledGrid",componentId:"sc-a4bebbc4-1"})`
  gap: 0;
  max-width: var(--customer-container-width);
  margin: 74px auto auto;

  ${h.default.above(i.bp.laptopSm,`
    grid-template-columns: 2fr 1.4fr;
  `)}

  ${h.default.below(i.bp.laptopSm,`
    grid-template-columns: repeat(2, 1fr);
  `)}
`,v=(0,f.default)(m.default).withConfig({displayName:"ImageGrid__TwoColumnGrid",componentId:"sc-a4bebbc4-2"})`
  grid-template-columns: repeat(2, 1fr);
  gap: 0;
`,w=f.default.div.withConfig({displayName:"ImageGrid__Illustration",componentId:"sc-a4bebbc4-3"})`
  position: relative;
  background-color: var(--gold);
  overflow: hidden;

  img {
    position: absolute;
    bottom: 0;
    left: 0;
    width: 100%;
  }
`,x=(0,f.default)(p.default).withConfig({displayName:"ImageGrid__CTA",componentId:"sc-a4bebbc4-4"})`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: var(--gold);
  background-color: var(--brand-black);
  font-size: ${(0,g.rem)(14)};
  text-transform: uppercase;
  transition: color 300ms ease-in-out, background-color 300ms ease-in-out;

  svg {
    max-width: 19px;
    margin-bottom: 10px;
  }

  ${(0,i.hover)(`
    color: var(--white);
    background-color: var(--gold);
  `)}
`,y=({title:a,description:b,imageOne:c,imageTwo:e,imageThree:f,imageFour:g,graphic:h,link:i,linkText:k})=>(0,d.jsx)(t,{hasPadding:!0,children:(0,d.jsxs)(l.default,{children:[a?(0,d.jsx)(o.Ninety,{as:"h2",children:a}):null,b?(0,d.jsx)(r.default,{content:b}):null,(0,d.jsxs)(u,{children:[(0,d.jsxs)(v,{children:[c?(0,d.jsx)(n.default,{src:`${c?.url}&w=412&h=576&fit=crop&q=85&fm=pjpg`,alt:c?.alt,width:412,height:576}):null,e?(0,d.jsx)(n.default,{src:`${e?.url}&w=412&h=576&fit=crop&q=85&fm=pjpg`,alt:e?.alt,width:412,height:576}):null]}),(0,d.jsxs)(v,{children:[(0,d.jsx)(w,{children:h?(0,d.jsx)("img",{src:h.url,alt:h.alt}):null}),f?(0,d.jsx)(n.default,{src:`${f?.url}&w=285&h=286&fit=crop&q=85&fm=pjpg`,alt:f?.alt,width:285,height:286}):null,(0,d.jsx)("div",{children:i?(0,d.jsxs)(x,{href:(0,j.linkResolver)(i),children:[(0,d.jsx)(q.default,{}),(0,d.jsx)("span",{children:k})]}):null}),g?(0,d.jsx)(n.default,{src:`${g?.url}&w=285&h=286&fit=crop&q=85&fm=pjpg`,alt:g?.alt,width:285,height:286}):null]})]})]})});y.propTypes={title:e.default.string,description:e.default.array,imageOne:e.default.object,imageTwo:e.default.object,imageThree:e.default.object,imageFour:e.default.object,graphic:e.default.object,link:e.default.object,linkText:e.default.string},a.s(["default",0,y]),c()}catch(a){c(a)}},!1),37840,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(19608),i=a.i(93631),j=a.i(760),k=a.i(64472),l=a.i(8444),m=a.i(15935),n=a.i(31164),o=b([h]);[h]=o.then?(await o)():o;let p=f.default.section.withConfig({displayName:"PreFooter__StyledSection",componentId:"sc-a3982354-0"})`
  color: var(--brand-white);
  text-align: center;
`,q=(0,f.default)(j.default).withConfig({displayName:"PreFooter__StyledGrid",componentId:"sc-a3982354-1"})`
  gap: 0;

  ${g.default.above(i.bp.laptopSm,`
    grid-template-columns: repeat(2, 1fr);
  `)}
`,r=f.default.li.withConfig({displayName:"PreFooter__ListItem",componentId:"sc-a3982354-2"})`
  position: relative;
  padding: 266px 0;

  ${g.default.below(i.bp.desktopSm,`
    padding: 200px 0;
  `)}

  ${g.default.below(i.bp.laptopSm,`
    padding: 134px 0;
  `)}
`,s=f.default.div.withConfig({displayName:"PreFooter__ListImage",componentId:"sc-a3982354-3"})`
  position: absolute;
  top: 0;
  left: 0;
  z-index: -1;
  width: 100%;
  height: 100%;

  &::before {
    position: absolute;
    top: 0;
    left: 0;
    z-index: 1;
    width: 100%;
    height: 100%;
    background-color: var(--${a=>a.bgcolor});
    opacity: .8;
    content: "";
  }
`,t=({leftTitle:a,leftLink:b,leftLinkText:c,leftImage:e,rightTitle:f,rightLink:g,rightLinkText:i,rightImage:j})=>(0,d.jsx)(p,{children:(0,d.jsxs)(m.default,{as:q,children:[(0,d.jsxs)(r,{children:[e?(0,d.jsx)(s,{bgcolor:"gold",children:(0,d.jsx)(n.default,{src:`${e.url}&w=900&h=690&fit=crop&q=85&fm=pjpg`,alt:e.alt})}):null,a?(0,d.jsx)(l.Ninety,{children:a}):null,b?(0,d.jsx)(k.default,{large:!0,isdark:!0,hasmargin:!0,bgcolor:"brand-black",href:(0,h.linkResolver)(b),children:c}):null]}),(0,d.jsxs)(r,{children:[j?(0,d.jsx)(s,{bgcolor:"brand-black",children:(0,d.jsx)(n.default,{src:`${j.url}&w=900&h=690&fit=crop&q=85&fm=pjpg`,alt:j.alt})}):null,f?(0,d.jsx)(l.Ninety,{children:f}):null,g?(0,d.jsx)(k.default,{large:!0,isdark:!0,hasmargin:!0,bgcolor:"gold",href:(0,h.linkResolver)(g),children:i}):null]})]})});t.propTypes={leftTitle:e.default.string,leftLink:e.default.object,leftLinkText:e.default.string,leftImage:e.default.object,rightTitle:e.default.string,rightLink:e.default.object,rightLinkText:e.default.string,rightImage:e.default.object},a.s(["default",0,t]),c()}catch(a){c(a)}},!1),21614,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(65762),f=a.i(47659),g=a.i(82181),h=a.i(22124),i=a.i(18175),j=a.i(10919),k=a.i(57915),l=a.i(37840),m=a.i(9959),n=a.i(91169),o=a.i(10512),p=b([f,g,h,i,j,k,l,m,n]);async function q({preview:a,previewData:b}){let c=(0,f.createClient)({previewData:b});return{props:{page:await c.getSingle("process")||{}}}}[f,g,h,i,j,k,l,m,n]=p.then?(await p)():p,a.s(["default",0,({page:a})=>{let{modalOpen:b}=(0,n.useModal)();if(!a)return null;let{data:c}=a;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.Helmet,{title:c?.page_title,meta:[{name:"description",content:c?.page_description},{property:"og:title",content:c?.page_title},{property:"og:description",content:c?.page_description},{property:"og:image",content:`${c?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:image",content:`${c?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:title",content:c?.page_title},{name:"twitter:description",content:c?.page_description}]}),(0,d.jsxs)("main",{children:[(0,d.jsx)(g.default,{title:c?.hero_title,subTitle:c?.hero_sub_title,description:c?.hero_description,image:c?.hero_image,videoId:c?.hero_video_id}),(0,d.jsx)(h.default,{title:c?.intro_title,description:c?.intro_description,graphic:c?.intro_graphic}),(0,d.jsx)(i.default,{steps:c?.steps}),(0,d.jsx)(j.default,{title:c?.image_grid_title,description:c?.image_grid_description,imageOne:c?.image_grid_image_one,imageTwo:c?.image_grid_image_two,imageThree:c?.image_grid_image_three,imageFour:c?.image_grid_image_four,graphic:c?.image_grid_graphic,link:c?.image_grid_link,linkText:c?.image_grid_link_text}),(0,d.jsx)(k.default,{image:c?.quote_image,quote:c?.quote,quotee:c?.quotee,title:c?.quote_title,description:c?.quote_description,link:c?.quote_link,linkText:c?.quote_link_text}),(0,d.jsx)(l.default,{leftTitle:c?.two_column_left_title,leftLink:c?.two_column_left_link,leftLinkText:c?.two_column_left_link_text,leftImage:c?.two_column_left_image,rightTitle:c?.two_column_right_title,rightLink:c?.two_column_right_link,rightLinkText:c?.two_column_right_link_text,rightImage:c?.two_column_right_image})]}),(0,d.jsx)(m.default,{children:(0,d.jsx)(o.default,{youTubeID:b})})]})},"getStaticProps",()=>q]),c()}catch(a){c(a)}},!1),63015,a=>a.a(async(b,c)=>{try{var d=a.i(43308),e=a.i(81245),f=a.i(42158),g=a.i(67684),h=a.i(76695),i=a.i(21614),j=a.i(42369),k=b([h,i]);[h,i]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/process/index",pathname:"/process",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/process/index",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_75b6dc84._.js.map
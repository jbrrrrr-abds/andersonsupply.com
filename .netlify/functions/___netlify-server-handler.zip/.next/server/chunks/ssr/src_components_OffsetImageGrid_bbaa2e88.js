module.exports=[68150,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(46283),f=a.i(760),g=a.i(15749),h=b([g]);[g]=h.then?(await h)():h;let i=(0,e.default)(f.default).withConfig({displayName:"OffsetImageGrid__ImageGrid",componentId:"sc-510a7817-0"})`
  grid-template-columns: ${a=>a.smallImageLeft?"1fr 2.5fr":"2.5fr 1fr"};
  gap: 30px;
`,j=(0,e.default)(g.default).withConfig({displayName:"OffsetImageGrid__SmallImage",componentId:"sc-510a7817-1"})`
  order: ${a=>a.smallImageLeft?"1":"2"};
`,k=(0,e.default)(g.default).withConfig({displayName:"OffsetImageGrid__BigImage",componentId:"sc-510a7817-2"})`
  order: ${a=>a.smallImageLeft?"2":"1"};
`;a.s(["default",0,({smallImageLeft:a,className:b,smallImage:c,bigImage:e})=>(0,d.jsxs)(i,{smallImageLeft:a,className:b,children:[c?.url?(0,d.jsx)(j,{width:397,height:544,src:`${c.url}&w=397&h=544&fit=crop&q=85&f=center`,smallImageLeft:a,alt:c.alt}):null,e?.url?(0,d.jsx)(k,{width:968,height:544,src:`${e.url}&w=968&h=544&fit=crop&q=85&f=center`,smallImageLeft:a,alt:e.alt}):null]})]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=src_components_OffsetImageGrid_bbaa2e88.js.map
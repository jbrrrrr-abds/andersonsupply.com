module.exports=[50882,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(93631),i=a.i(19608),j=a.i(35688),k=a.i(10424),l=a.i(15935),m=a.i(6912),n=a.i(8444),o=a.i(64472),p=a.i(760),q=a.i(94905),r=b([i,q]);[i,q]=r.then?(await r)():r;let s=(0,f.default)(k.default).withConfig({displayName:"RecentWorkCarousel__StyledSection",componentId:"sc-d888e885-0"})`
  padding: var(--spacing) 0 94px;

  ${g.default.below(h.bp.mobile,`
    padding-bottom: 20px;
  `)}
`,t=f.default.div.withConfig({displayName:"RecentWorkCarousel__HeadlineWrapperContainer",componentId:"sc-d888e885-1"})`
  position: relative;
`,u=(0,f.default)(k.default).withConfig({displayName:"RecentWorkCarousel__Headline",componentId:"sc-d888e885-2"})`
  top: -66px;
  position: absolute;
  display: flex;
  justify-content: center;
  align-items: center;
  width: 100%;
  overflow: hidden;

  ${g.default.below(h.bp.desktop,`
    top: -50px;
  `)}
`,v=(0,f.default)(n.Ninety).withConfig({displayName:"RecentWorkCarousel__HeadlineText",componentId:"sc-d888e885-3"})`
  width: 30rem;

  ${g.default.below(h.bp.desktopSm,`
    width: 23rem;
  `)}
`,w=(0,f.default)(l.default).withConfig({displayName:"RecentWorkCarousel__List",componentId:"sc-d888e885-4"})`
  width: 150%;
  display: flex;
`,x=f.default.div.withConfig({displayName:"RecentWorkCarousel__Wrapper",componentId:"sc-d888e885-5"})`
  width: 100%;
  position: relative;
  margin-top: 60px;
`,y=(0,f.default)(p.default).withConfig({displayName:"RecentWorkCarousel__OurWorkFooter",componentId:"sc-d888e885-6"})`
  grid-template-columns: 324px 1fr;
  column-gap: 74px;
  margin-top: 40px;
  opacity: 0;
  transition: opacity 300ms ease-in-out;

  p {
    margin-bottom: 35px;
  }

  ${g.default.between(h.bp.tablet,h.bp.desktopSm,`
    grid-template-columns: 244px 1fr;
    grid-column-gap: 40px;
  `)}

  ${g.default.below(h.bp.tablet,`
    grid-template-columns: 1fr;
    grid-row-gap: 20px;
    text-align: center;
  `)}
`,z=(0,f.default)(j.default.Slide).withConfig({displayName:"RecentWorkCarousel__Slide",componentId:"sc-d888e885-7"})`
  width: 62%;
  margin-right: 174px;

  && {
    opacity: 1;
  }

  ${g.default.below(h.bp.desktopLg,`
    margin-right: 130px;
  `)}

  ${g.default.below(h.bp.desktop,`
    margin-right: 88px;
  `)}

  ${g.default.below(h.bp.desktopSm,`
    width: 71%;
    margin-right: 44px;
  `)}

  &.is-selected {
    ${y} {
      opacity: 1;
    }
  }
`,A=(0,f.default)(m.default).withConfig({displayName:"RecentWorkCarousel__OurWorkFooterLogo",componentId:"sc-d888e885-8"})`
  margin-top: 20px;

  ${g.default.below(h.bp.tablet,`
    margin: auto;
  `)}
`,B=f.default.div.withConfig({displayName:"RecentWorkCarousel__OurWorkBlurb",componentId:"sc-d888e885-9"})`
  margin-bottom: 35px;
`,C=({slides:a=[]})=>{let{flickity:b}=(0,j.useCarousel)(),c=Array.from([,,,,,],()=>"RECENT WORK");return a.length<1?null:(0,d.jsx)(s,{hasPadding:!0,bgColor:"brand-white",children:(0,d.jsxs)(t,{children:[(0,d.jsx)(u,{"aria-hidden":"true",children:c.length>0?(0,d.jsx)(w,{children:c.map((a,b)=>(0,d.jsx)("li",{children:(0,d.jsx)(v,{children:a})},b))}):null}),(0,d.jsx)(x,{children:(0,d.jsx)(j.default,{ref:b,children:a.map((a,b)=>(0,d.jsxs)(z,{children:[a?.recent_work_image?(0,d.jsx)(m.default,{width:1110,height:672,src:a.recent_work_image?.url,alt:a.recent_work_image?.alt}):null,(0,d.jsxs)(y,{children:[a?.recent_work_logo?(0,d.jsx)(A,{src:a.recent_work_logo?.url,alt:a.recent_work_logo?.alt}):null,(0,d.jsxs)(B,{children:[a?.recent_work_description?(0,d.jsx)(q.default,{content:a.recent_work_description}):null,a?.recent_work_link?(0,d.jsx)(o.default,{large:!0,bgcolor:"gold",isdark:!0,hasmargin:!0,href:(0,i.linkResolver)(a.recent_work_link),children:a.recent_work_link_text}):null]})]})]},b))})})]})})};C.propTypes={slides:e.default.array},a.s(["default",0,C]),c()}catch(a){c(a)}},!1),31646,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(49933),i=a.i(19608),j=a.i(93631),k=a.i(10424),l=a.i(68178),m=a.i(15749),n=a.i(760),o=a.i(45491),p=a.i(86011),q=b([i,m]);[i,m]=q.then?(await q)():q;let r=(0,f.default)(k.default).withConfig({displayName:"ProductGrid__StyledSection",componentId:"sc-c69df9a5-0"})`
  text-align: center;

  p {
    max-width: 827px;
    margin: auto;
  }
`,s=(0,f.default)(n.default).withConfig({displayName:"ProductGrid__StyledGrid",componentId:"sc-c69df9a5-1"})`
  gap: 0;

  ${g.default.above(j.bp.tablet,`
    grid-template-columns: 1.4fr 1fr;
  `)}
`,t=(0,f.default)(n.default).withConfig({displayName:"ProductGrid__TwoColumnGrid",componentId:"sc-c69df9a5-2"})`
  grid-template-columns: 1fr 1fr;
  gap: 0;
`,u=(0,f.default)(m.default).withConfig({displayName:"ProductGrid__SpanTwo",componentId:"sc-c69df9a5-3"})`
  grid-column: span 2;
`,v=(0,f.default)(o.default).withConfig({displayName:"ProductGrid__CTA",componentId:"sc-c69df9a5-4"})`
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: center;
  height: 100%;
  color: var(--gold);
  background-color: var(--brand-white);
  font-size: ${(0,h.rem)(14)};
  text-transform: uppercase;
  transition: color 300ms ease-in-out, background-color 300ms ease-in-out;

  svg {
    max-width: 19px;
    margin-bottom: 10px;
  }

  ${(0,j.hover)(`
    color: var(--white);
    background-color: var(--gold);
  `)}
`,w=({images:a=[],link:b,linkText:c})=>{if(a.length<1)return null;let e=a[0]?.image,f=a[1]?.image,g=a[2]?.image,h=a[3]?.image,j=a[4]?.image,k=a[5]?.image,n=a[6]?.image;return(0,d.jsx)(r,{bgColor:"brand-white",children:(0,d.jsx)(l.default,{children:(0,d.jsxs)(s,{children:[(0,d.jsxs)(t,{children:[e?(0,d.jsx)(m.default,{src:`${e.url}&w=412&h=686&fit=crop&q=85&f=center`,alt:e.alt,width:412,height:686}):null,f?(0,d.jsx)(m.default,{src:`${f.url}&w=412&h=686&fit=crop&q=85&f=center`,alt:f.alt,width:412,height:686}):null,g?(0,d.jsx)(u,{src:`${g.url}&w=824&h=465&fit=crop&q=85&f=center`,alt:g.alt,width:824,height:465}):null]}),(0,d.jsxs)(t,{children:[h?(0,d.jsx)(m.default,{src:`${h.url}&w=285&h=285&fit=crop&q=85&f=center`,alt:h.alt,width:285,height:285}):null,j?(0,d.jsx)(m.default,{src:`${j.url}&w=285&h=285&fit=crop&q=85&f=center`,alt:j.alt,width:285,height:285}):null,b?(0,d.jsx)("div",{children:(0,d.jsxs)(v,{href:(0,i.linkResolver)(b),children:[(0,d.jsx)(p.default,{}),(0,d.jsx)("span",{children:c})]})}):null,k?(0,d.jsx)(m.default,{src:`${k.url}&w=285&h=285&fit=crop&q=85&f=center`,alt:k.alt,width:285,height:285}):null,n?(0,d.jsx)(u,{src:`${n.url}&w=572&h=572&fit=crop&q=85&f=center`,alt:n.alt,width:572,height:572}):null]})]})})})};w.propTypes={images:e.default.array,link:e.default.object,linkText:e.default.string},a.s(["default",0,w]),c()}catch(a){c(a)}},!1),92509,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(27899),g=a.i(46283),h=a.i(74852),i=a.i(51176),j=a.i(5235),k=a.i(92802),l=a.i(93631),m=a.i(15749),n=a.i(10424),o=a.i(92593),p=b([m]);[m]=p.then?(await p)():p;let q=(0,g.default)(n.default).withConfig({displayName:"MoreWorkCarousel__MoreWorkContainer",componentId:"sc-6bd4cc66-0"})`
  padding: 106px 0 var(--spacing) 0;
  position: relative;
`,r=g.default.div.withConfig({displayName:"MoreWorkCarousel__Header",componentId:"sc-6bd4cc66-1"})`
  margin-left: var(--container-gutter);
  display: flex;
  align-items: center;

  h2 {
    margin: 0 25px 0 0;
  }
`,s=(0,g.default)(o.default).withConfig({displayName:"MoreWorkCarousel__SlideArrowButton",componentId:"sc-6bd4cc66-2"})`
  transform: scale(-1);
  background: transparent;
  transition: color 300ms ease-in-out;

  ${(0,l.hover)(`
    background: transparent;
    color: var(--gold);
  `)}
`,t=g.default.svg.withConfig({displayName:"MoreWorkCarousel__SlideArrow",componentId:"sc-6bd4cc66-3"})`
  width: 32px;
  height: 8px;
  color: inherit;
`,u=g.default.div.withConfig({displayName:"MoreWorkCarousel__ScrollWrapper",componentId:"sc-6bd4cc66-4"})`
  width: 100%;
  position: relative;
  overflow: hidden;
  padding: 0 0 0 var(--container-gutter);
`,v=g.default.div.withConfig({displayName:"MoreWorkCarousel__Scroller",componentId:"sc-6bd4cc66-5"})`
  display: flex;
  flex-wrap: nowrap;
`,w=g.default.div.withConfig({displayName:"MoreWorkCarousel__Slide",componentId:"sc-6bd4cc66-6"})`
  --slide-padding: 30px;

  min-width: 27.4%;
  width: 27.4%;
  opacity: 1;
  padding-right: var(--slide-padding);

  &:last-of-type {
    padding-right: 0;
    min-width: calc(27.4% - var(--slide-padding));
    width: calc(27.4% - var(--slide-padding));
  }

  ${h.default.below(l.bp.desktop,`
    --slide-padding: 15px;
  `)}

  ${h.default.below(l.bp.mobile,`
    min-width: 56%;
    width: 56%;

    &:last-of-type {
      min-width: calc(56% - var(--slide-padding));
      width: calc(56% - var(--slide-padding));
    }
  `)}
`,x=(0,g.default)(m.default).withConfig({displayName:"MoreWorkCarousel__Image",componentId:"sc-6bd4cc66-7"})`
  margin-top: 34px;
`,y=({title:a,slides:b=[]})=>{let c=(0,e.useRef)(),f=(0,e.useRef)(),g=(0,e.useRef)(),h=(0,e.useRef)(),l=(0,e.useCallback)(a=>{a&&(c.current=a)},[]);return((0,e.useEffect)(()=>{if(!window||!c.current)return;f.current=c.current.querySelector(".scroller"),h.current=f.current.children;let a=h.current[0];i.default.registerPlugin(j.default,k.default),g.current=f.current.offsetWidth-c.current.scrollWidth,j.default.create(f.current,{type:"x",bounds:{minX:f.current.offsetWidth-c.current.scrollWidth,maxX:0},snap:b=>Math.round(b/a.offsetWidth)*a.offsetWidth,inertia:!0});let b=()=>{g.current=f.current.offsetWidth-c.current.scrollWidth,i.default.set(f.current,{x:0}),j.default.get(f.current).applyBounds({minX:g.current,maxX:0})};return window.addEventListener("resize",b),()=>{window.removeEventListener("resize",b),j.default.get(f.current).kill()}},[]),b.length<1)?null:(0,d.jsxs)(q,{bgColor:"brand-white",children:[(0,d.jsxs)(r,{children:[a?(0,d.jsx)("h2",{children:a}):null,(0,d.jsx)(s,{onClick:()=>{let a=h.current[0].offsetWidth;f.current.offsetWidth-c.current.scrollWidth<i.default.getProperty(f.current,"x")?i.default.to(f.current,{x:`-=${a}`}):f.current.offsetWidth-c.current.scrollWidth<0&&i.default.to(f.current,{x:g.current})},children:(0,d.jsx)(t,{viewBox:"0 0 32 8",xmlns:"http://www.w3.org/2000/svg",fill:"none",children:(0,d.jsx)("path",{d:"M3.99 5H31.5V3H3.99V0L0 4l3.99 4V5z",fill:"currentColor"})})})]}),(0,d.jsx)(u,{ref:l,children:(0,d.jsx)(v,{className:"scroller",children:b.map((a,b)=>(0,d.jsx)(w,{children:(0,d.jsx)(x,{src:a.more_work_image?.url||"",alt:a.more_work_image?.alt||"",width:397,height:585})},b))})})]})};y.propTypes={title:f.default.string,slides:f.default.array},a.s(["default",0,y]),c()}catch(a){c(a)}},!1),96875,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(19608),g=a.i(10424),h=a.i(68178),i=a.i(64472),j=a.i(78356),k=a.i(94905),l=b([f,j,k]);[f,j,k]=l.then?(await l)():l;let m=({image:a,title:b,description:c,linkText:e,linkUrl:l})=>(0,d.jsx)(g.default,{hasPadding:!0,bgColor:"brand-white",children:(0,d.jsx)(h.default,{children:(0,d.jsxs)(j.default,{imageLeft:!0,image:a,children:[b?(0,d.jsx)("h2",{children:b}):null,c?(0,d.jsx)(k.default,{content:c}):null,l?(0,d.jsx)(i.default,{large:!0,isdark:!0,bgcolor:"gold",hasmargin:!0,href:(0,f.linkResolver)(l),children:e}):null]})})});m.propTypes={image:e.default.object,title:e.default.string,description:e.default.array,linkText:e.default.string,linkUrl:e.default.object},a.s(["default",0,m]),c()}catch(a){c(a)}},!1),70188,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(65762),f=a.i(47659),g=a.i(50882),h=a.i(31646),i=a.i(92509),j=a.i(60509),k=a.i(96875),l=a.i(75305),m=a.i(40576),n=b([f,g,h,i,j,k,l]);async function o({preview:a,previewData:b}){let c=(0,f.createClient)({previewData:b});return{props:{page:await c.getSingle("work",{fetchLinks:["testimonial.quote","testimonial.quotee","marquee.first_text_content","marquee.second_text_content","marquee.third_text_content","marquee.link","marquee.link_text"]})||{}}}}[f,g,h,i,j,k,l]=n.then?(await n)():n,a.s(["default",0,({page:a})=>{if(!a)return null;let{data:b}=a;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.Helmet,{title:b?.page_title,meta:[{name:"description",content:b?.page_description},{property:"og:title",content:b?.page_title},{property:"og:description",content:b?.page_description},{property:"og:image",content:`${b?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:image",content:`${b?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:title",content:b?.page_title},{name:"twitter:description",content:b?.page_description}]}),(0,d.jsxs)("main",{children:[(0,d.jsx)(m.default,{title:b?.work_title,logoRowOne:b?.logo_row_one,logoRowTwo:b?.logo_row_two,logoRowThree:b?.logo_row_three,logoRowFour:b?.logo_row_four}),(0,d.jsx)(g.default,{slides:b?.recent_work}),(0,d.jsx)(h.default,{images:b?.product_grid,link:b?.product_grid_link,linkText:b?.product_grid_link_text}),(0,d.jsx)(i.default,{title:b?.more_work_title,slides:b?.more_work}),(0,d.jsx)(j.default,{padding:!0,title:b?.testimonials_title,testimonials:b?.testimonials,image:b?.testimonials_background}),(0,d.jsx)(k.default,{image:b?.two_column_image,title:b?.two_column_title,description:b?.two_column_description,linkText:b?.two_column_link_text,linkUrl:b?.two_column_link}),(0,d.jsx)(l.default,{marqueeID:a?.id,content:b?.marquee?.data})]})]})},"getStaticProps",()=>o]),c()}catch(a){c(a)}},!1),50109,a=>a.a(async(b,c)=>{try{var d=a.i(43308),e=a.i(81245),f=a.i(42158),g=a.i(67684),h=a.i(76695),i=a.i(70188),j=a.i(42369),k=b([h,i]);[h,i]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/work/index",pathname:"/work",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/work/index",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_ac83143c._.js.map
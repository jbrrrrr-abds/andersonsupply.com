module.exports=[72253,a=>{"use strict";var b=a.i(8171);a.i(27669);var c=a.i(46283),d=a.i(27899),e=a.i(93631),f=a.i(92593);let g=(0,c.default)(f.default).withConfig({displayName:"PlayButton__StyledPlayButton",componentId:"sc-7822558f-0"})`
  position: relative;
  min-width: 68px;
  min-height: 68px;
  color: var(--brand-white);
  background-color: var(--gold);
  border-radius: 50%;
  transition: color 300ms ease-in-out, background-color 300ms ease-in-out;

  svg {
    position: absolute;
    top: 50%;
    left: 50%;
    width: 12px;
    height: 14px;
    fill: currentcolor;
    transform: translate(-50%, -50%);
  }

  ${(0,e.hover)(`
    color: var(--brand-black);
    background-color: var(--brand-white);
  `)}
`,h=({label:a,className:c,playing:d,...e})=>(0,b.jsx)(g,{"aria-label":a,className:c,"aria-pressed":d,...e,children:d?(0,b.jsx)("svg",{width:"13",height:"18",viewBox:"0 0 13 18",xmlns:"http://www.w3.org/2000/svg",children:(0,b.jsx)("path",{d:"M0 0h4v18H0V0zm9 0h4v18H9V0z",fill:"currentColor"})}):(0,b.jsxs)("svg",{width:"12",height:"14",viewBox:"0 0 60 60",xmlns:"http://www.w3.org/2000/svg",children:[(0,b.jsx)("polygon",{points:"10 0 60 30 60 30 10 60"}),(0,b.jsx)("polygon",{points:"10 20 50 30 50 30 10 40"})]})});h.propTypes={label:d.default.string,className:d.default.string,playing:d.default.bool},a.s(["default",0,h])},10424,a=>{"use strict";var b=a.i(46283);let c=b.default.section.withConfig({displayName:"Section",componentId:"sc-47f70e12-0"})`
  ${a=>a.hasPadding&&`
    padding: var(--spacing) 0;
  `}

  ${a=>a.bgColor&&`
    background-color: var(--${a.bgColor});
  `}
`;a.s(["default",0,c])},6077,(a,b,c)=>{b.exports=a.x("prismic-reactjs",()=>require("prismic-reactjs"))},94905,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(46283),f=a.i(27899),g=a.i(6077),h=a.i(93631),i=a.i(19608),j=a.i(45491),k=b([i]);[i]=k.then?(await k)():k;let l=(0,e.default)(j.default).withConfig({displayName:"TextBlock__StyledLink",componentId:"sc-facd1adf-0"})`
  color: var(--gold);
  text-decoration: none;
  position: relative;
  transition: color 300ms ease;

  &::after {
    content: "";
    width: 100%;
    height: 2px;
    background: var(--brand-black);
    position: absolute;
    left: 0;
    bottom: -1px;
    transition: color 300ms ease;
  }

  ${(0,h.hover)(`
    color: var(--brand-black);

    &::after {
      color: var(--gold);
    }
  `)}
`,m=(a,b,c)=>(0,d.jsx)(l,{href:(0,i.linkResolver)(b.data),children:c},`${b.data.link_type}${b.start}`),n=({content:a,...b})=>a?(0,d.jsx)(g.RichText,{render:a,serializeHyperlink:m,...b}):null;n.propTypes={content:f.default.array},a.s(["default",0,n]),c()}catch(a){c(a)}},!1),86011,a=>{"use strict";var b=a.i(8171);a.i(27669),a.s(["default",0,()=>(0,b.jsx)("svg",{viewBox:"0 0 19 36",fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,b.jsx)("path",{d:"M0 20.102C5.979 13.784 18.15.919 19 0l-6.378 15.938H19L1.329 35.753l5.846-17.23L0 20.101z",fill:"currentColor"})})])},62677,a=>a.a(async(b,c)=>{try{let b=await a.y("zustand");a.n(b),c()}catch(a){c(a)}},!0),48324,(a,b,c)=>{b.exports=a.x("react-modal",()=>require("react-modal"))},91169,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(62677);a.i(27669);var f=a.i(48324),g=a.i(46283),h=a.i(49933),i=a.i(68178),j=a.i(92593),k=b([e]);[e]=k.then?(await k)():k;let l=(0,e.create)(a=>({modalOpen:!1,modalData:null,toggleModal:(b=!1,c=null)=>b?a(a=>({modalOpen:a.modalOpen!==b&&b,modalData:c})):a({modalOpen:!1,modalData:c})})),m=(0,g.default)(j.default).withConfig({displayName:"GullsModal__Close",componentId:"sc-61c13aa9-0"})`
  ${(0,h.size)(44)}
  ${(0,h.position)("fixed",20,20,null,null)}
  background-color: var(--gold);
  font-size: 1.5rem;
  line-height: 44px;
  border-radius: 50%;
  transition: all 0.3s;
`;a.s(["default",0,({className:a,appElement:b="#__next",children:c,...e})=>{let{modalOpen:g,toggleModal:h}=l();return f.default.setAppElement(b),(0,d.jsxs)(f.default,{isOpen:!!g,onRequestClose:()=>{h()},overlayClassName:"Overlay",className:"Modal",portalClassName:a,...e,children:[(0,d.jsx)(m,{"aria-label":"close modal",onClick:()=>{h()},children:"×"}),(0,d.jsx)(i.default,{children:c})]})},"useModal",0,l]),c()}catch(a){c(a)}},!1),9959,a=>a.a(async(b,c)=>{try{var d=a.i(46283),e=a.i(91169),f=b([e]);[e]=f.then?(await f)():f;let g=d.keyframes`
  0%   {
    background-color: rgba(0, 0, 0, 0);
  }

  100% {
    background-color: rgba(0, 0, 0, .75);
  }
`,h=(0,d.default)(e.default).withConfig({displayName:"Modal",componentId:"sc-1bd14926-0"})`
  .Overlay {
    z-index: 200;
    display: flex;
    justify-content: center;
    align-items: center;
    position: fixed;
    inset: 0;
    background-color: rgb(0 0 0 / 75%);
    animation: 1.2s ${g} ease-in;
  }

  .Modal {
    position: relative;
    width: 100%;
    border: 0;
    outline: none;
    text-align: center;

    /** Allows parent to determine width and not affect
        clickable area to close modal. Questions? Ask Brett 😑
     */
    pointer-events: none;

    > div { pointer-events: auto; }
  }
`;a.s(["default",0,h]),c()}catch(a){c(a)}},!1),10512,a=>{"use strict";var b=a.i(8171);a.i(27669);var c=a.i(46283),d=a.i(93631);let e=c.default.div.withConfig({displayName:"YouTubeModal__VidWrap",componentId:"sc-e49682ff-0"})`
  overflow: hidden;
  padding-bottom: 56.25%; /* assuming 16:9 ratio */
  position: relative;
  height: 0;

  iframe {
    height: 100%;
    width: 100%;
    max-height: 90vh;
    ${(0,d.absoCenter)()}
  }
`;a.s(["default",0,({youTubeID:a})=>(0,b.jsx)(e,{children:(0,b.jsx)("iframe",{src:`https://www.youtube.com/embed/${a}?rel=0&autoplay=1`,frameBorder:"0",allow:"accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture",allowFullScreen:!0})})])},21428,(a,b,c)=>{b.exports=a.x("gsap/dist/ScrollToPlugin.js",()=>require("gsap/dist/ScrollToPlugin.js"))},31164,a=>{"use strict";var b=a.i(46283);let c=b.default.img.withConfig({displayName:"AbsoluteImage",componentId:"sc-7b648c5d-0"})`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`;a.s(["default",0,c])},24463,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(27899),g=a.i(46283),h=a.i(51176),i=a.i(74852),j=a.i(49933),k=a.i(19608),l=a.i(93631),m=a.i(15935),n=a.i(8444),o=a.i(45491),p=b([k]);[k]=p.then?(await p)():p;let q=g.default.li.withConfig({displayName:"ServicesList__StyledListItem",componentId:"sc-a436be1-0"})`
  max-width: 1220px;
  position: relative;
  z-index: 2;

  ${a=>!a.isServicesPage&&`
    border-bottom: 3px solid var(--border-color);

    &:first-of-type {
      border-top: 3px solid var(--border-color);
    }
  `}
`,r=(0,g.default)(o.default).withConfig({displayName:"ServicesList__StyledLink",componentId:"sc-a436be1-1"})`
  transition: color 300ms ease;

  ${(0,l.hover)(`
    color: var(--gold);
  `)}
`,s=g.default.span.withConfig({displayName:"ServicesList__ListText",componentId:"sc-a436be1-2"})`
  ${i.default.below(l.bp.mobile,`
    font-size: ${(0,j.rem)(50)};
  `)}
`,t=g.default.div.withConfig({displayName:"ServicesList__ImageWrapper",componentId:"sc-a436be1-3"})`
  position: absolute;
  top: ${a=>a.isServicesPage?"290px":"0"};
  width: ${a=>a.isServicesPage?"825px":"100%"};
  height: ${a=>a.isServicesPage?"1116px":"100%"};
  overflow: hidden;
  z-index: 0;

  img {
    position: absolute;
    width: 100%;
    height: 100%;
    object-fit: cover;
  }

  ${a=>a.isServicesPage&&`
    right: var(--container-gutter);

    ${i.default.above(l.bp.laptopSm,`
      margin-top: -52px;
    `)}
  `}

  ${a=>!a.isServicesPage&&`
    left: 0;
    width: 100%;
    height: 100%;
    filter: grayscale(100%);

    &::before {
      position: absolute;
      top: 0;
      left: 0;
      z-index: 1;
      width: 100%;
      height: 100%;
      background-color: var(--brand-black);
      opacity: .4;
      content: "";
    }
  `}

  ${a=>i.default.below(l.bp.desktopSm,`
    top: ${a.isServicesPage&&"218px"};
    width: ${a.isServicesPage&&"618px"};
    height: ${a.isServicesPage&&"837px"};
  `)}

  ${a=>i.default.below(l.bp.laptopSm,`
    top: ${a.isServicesPage&&"unset"};
    width: ${a.isServicesPage&&"100%"};
    height: ${a.isServicesPage&&"100%"};
    left: 0;
    bottom: 0;
  `)}
`,u=({services:a=[],isServicesPage:b,className:c})=>{let f=(0,e.useRef)(),g=(0,e.useRef)(0);return a?.length<1?null:(0,d.jsxs)("div",{ref:f,children:[(0,d.jsx)(m.default,{className:c,children:a.map((a,c)=>(0,d.jsx)(q,{isServicesPage:b,children:(0,d.jsx)(r,{onMouseEnter:()=>{(a=>{if(!f.current)return;let c=f.current.querySelectorAll(".service-image"),d=c[a],e=d.querySelector("img"),i=c[g.current];if(a!==g.current){if(h.default.set(c,{zIndex:-2}),h.default.set(i,{zIndex:-1}),h.default.set(d,{zIndex:0}),b)h.default.set([d,e],{transformOrigin:"50% 100%"}),h.default.fromTo(d,{scaleY:.01},{scaleY:1,duration:.6,ease:"sine.inOut",onUpdate:()=>{h.default.set(e,{scaleY:1/h.default.getProperty(d,"scaleY")})}});else{let a=h.default.timeline({immediateRender:!1,onComplete:()=>{a.kill()}}).fromTo(d,{scale:.01},{scale:1,onUpdate:()=>{h.default.set(e,{scale:1/h.default.getProperty(d,"scale")})}}).fromTo(d,{borderRadius:"50%"},{borderRadius:0},"-=.25")}g.current=a}})(c)},className:"service-text",href:(0,k.linkResolver)(a?.link_url),children:(0,d.jsx)(s,{as:n.OneSixty,children:a?.name})})},c))}),a.map((a,c)=>(0,d.jsx)(t,{className:"service-image",isServicesPage:b,children:(0,d.jsx)("img",{src:`${a.image.url}&w=825&h=825&fit=crop&q=85&f=center`,alt:a.image.alt})},c))]})};u.propTypes={services:f.default.array,isServicesPage:f.default.bool,className:f.default.string},a.s(["default",0,u]),c()}catch(a){c(a)}},!1),75305,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(51176),g=a.i(43124),h=a.i(46283),i=a.i(49933),j=a.i(74852),k=a.i(19608),l=a.i(93631),m=a.i(8444),n=a.i(86011),o=a.i(45491),p=b([k]);[k]=p.then?(await p)():p;let q=h.default.div.withConfig({displayName:"MarqueeBlock__Wrapper",componentId:"sc-58b4aa9e-0"})`
  overflow: hidden;
  height: 188px;
  position: relative;
  max-width: 100%;
  width: 100%;

  ${j.default.below(l.bp.desktopSm,`
    height: 150px;
  `)}

  ${j.default.below(l.bp.portrait,`
    height: 105px;
  `)}
`,r=(0,h.default)(o.default).withConfig({displayName:"MarqueeBlock__CTA",componentId:"sc-58b4aa9e-1"})`
  display: inline-block;
  padding: 42px;
  text-align: center;
  color: var(--gold);
  text-transform: uppercase;
  white-space: nowrap;

  ${j.default.below(l.bp.desktopSm,`
    padding: 22px;
  `)}

  ${j.default.below(l.bp.portrait,`
    padding: 8px 22px 0;
  `)}

  svg {
    display: block;
    max-width: 19px;
    margin: auto auto 10px;

    ${j.default.below(l.bp.portrait,`
       margin-bottom: 0;
    `)}
  }
`,s=h.default.div.withConfig({displayName:"MarqueeBlock__Item",componentId:"sc-58b4aa9e-2"})`
  display: block;
  position: absolute;
  left: 100%;
  top: 16px;

  span {
    white-space: nowrap;
    line-height: 1;
  }
`,t=(0,h.default)(m.OneSixty).withConfig({displayName:"MarqueeBlock__StyledOneSixty",componentId:"sc-58b4aa9e-3"})`
  ${j.default.below(l.bp.mobile,`
    font-size: ${(0,i.rem)(75)};
  `)}
`;a.s(["default",0,({content:a,marqueeID:b})=>{let c=(0,e.useRef)(),h=(0,e.useCallback)(()=>{g.default.getById(`${b}-marquee-scroll-trigger`)&&g.default.getById(`${b}-marquee-scroll-trigger`).kill(),c.current&&c.current.kill()},[b,c]),i=(0,e.useCallback)(a=>{if(!a)return;f.default.registerPlugin(g.default);let d=a.querySelectorAll(".marquee-item");g.default.addEventListener("refresh",()=>{f.default.set(d,{x:0}),h();let e=0,i=0;d.length&&d.forEach((a,b)=>{let c=f.default.getProperty(a,"width");b>0&&(f.default.set(a,{x:-1*(c+i)}),i+=c),e+=c}),c.current=f.default.to(d,{x:`-=${e}`,repeat:-1,duration:18,ease:"none",modifiers:{x:f.default.utils.unitize(a=>f.default.utils.wrap(-e,0,a))}}),g.default.create({trigger:a,animation:c.current,start:"top bottom",end:"bottom top",id:`${b}-marquee-scroll-trigger`})})},[h,b]),j=()=>{c.current&&c.current.pause()},l=()=>{c.current&&(c.current.play(),f.default.fromTo(c.current,{timeScale:0},{timeScale:1,ease:"power1.in"}))};return(0,e.useEffect)(()=>()=>{h()},[h]),(0,d.jsxs)(q,{ref:i,children:[a?.first_text_content?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsx)(t,{children:a?.first_text_content})}):null,a?.link?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsxs)(r,{onMouseEnter:j,onMouseLeave:l,href:(0,k.linkResolver)(a?.link),children:[(0,d.jsx)(n.default,{}),a?.link_text]})}):null,a?.second_text_content?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsx)(t,{children:a?.second_text_content})}):null,a?.link?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsxs)(r,{onMouseEnter:j,onMouseLeave:l,href:(0,k.linkResolver)(a?.link),children:[(0,d.jsx)(n.default,{}),a?.link_text]})}):null,a?.third_text_content?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsx)(t,{children:a?.third_text_content})}):null,a?.link?(0,d.jsx)(s,{className:"marquee-item",children:(0,d.jsxs)(r,{onMouseEnter:j,onMouseLeave:l,href:(0,k.linkResolver)(a?.link),children:[(0,d.jsx)(n.default,{}),a?.link_text]})}):null]})}]),c()}catch(a){c(a)}},!1),21207,(a,b,c)=>{b.exports=a.x("flickity",()=>require("flickity"))},35688,a=>{"use strict";var b=a.i(8171),c=a.i(27669),d=a.i(46283),e=a.i(27899),f=a.i(93631),g=a.i(15935),h=a.i(92593);let i=d.default.div.withConfig({displayName:"Carousel",componentId:"sc-36d723c4-0"})`
  position: relative;
  overflow: hidden;
  outline: none;
  width: 100%;

  .flickity-viewport {
    position: relative;
  }

  .flickity-slider {
    width: 100%;
    height: 100%;
  }
`;i.Slide=d.default.div.withConfig({displayName:"Carousel__Slide",componentId:"sc-36d723c4-1"})`
  width: 100%;
  opacity: 0;
  transition: opacity 300ms ease-in-out;

  &.is-selected {
    opacity: 1;
  }
`;let j=d.default.li.withConfig({displayName:"Carousel__SlideDot",componentId:"sc-36d723c4-2"})`
  display: inline-block;

  &:not(:last-of-type) {
    margin-right: 10px;
  }
`,k=(0,d.default)(h.default).withConfig({displayName:"Carousel__SlideDotButton",componentId:"sc-36d723c4-3"})`
  width: 7px;
  height: 7px;
  position: relative;
  display: inline-block;
  background-color: var(--${a=>a.isDark?"brand-white":"gold"});
  border-radius: 50%;
  transition: opacity .33s;
  opacity: .5;

  &[aria-current="true"] {
    opacity: 1;
  }

  /* expand the click area as much as possible */

  &::before {
    content: "";
    display: block;
    position: absolute;
    inset: -6px;
  }

  ${(0,f.hover)(`
    opacity: 1;
  `)}
`,l=(0,d.default)(h.default).withConfig({displayName:"Carousel__SlideArrowButton",componentId:"sc-36d723c4-4"})`
  ${a=>a.color&&`
    color: var(--${a.color});
  `}
  ${a=>a.isLeft&&"transform: scaleX(-1)"};
  transition: color 300ms ease-in-out;

  ${(0,f.hover)(`
    color: var(--gold);
  `)}
`,m=d.default.svg.withConfig({displayName:"Carousel__SlideArrow",componentId:"sc-36d723c4-5"})`
  width: 32px;
  height: 8px;
  color: inherit;
`;i.Dots=({slides:a=[],currentIndex:c,handleClick:d,className:e,isDark:f})=>(i.Dots.displayName="CarouselDots",!a||a&&a.length<2)?null:(0,b.jsx)(g.default,{className:e,children:a.map((a,e)=>(0,b.jsx)(j,{display:"inline-block",children:(0,b.jsx)(k,{"aria-label":`Go to slide ${e+1}`,"aria-current":e===c,isDark:f,onClick:()=>{d(e)}})},e))}),i.Dots.propTypes={slides:e.default.array,currentIndex:e.default.number,handleClick:e.default.func,className:e.default.string},i.Button=({slideCount:a,currentIndex:c,handleClick:d,actionName:e,isLeft:f,color:g})=>{i.Button.displayName="CarouselButton";let h=null,j="next"===e?1:-1;return h=c+j>=a?0:c+j<0?a-1:c+j,(0,b.jsx)(l,{"aria-label":`Go to ${e} slide`,onClick:()=>{d(h)},actionName:e,isLeft:f,color:g,children:(0,b.jsx)(m,{viewBox:"0 0 32 8",isLeft:f,fill:"none",xmlns:"http://www.w3.org/2000/svg",children:(0,b.jsx)("path",{d:"M3.99 5H31.5V3H3.99V0L0 4l3.99 4V5z",fill:"currentColor"})})})},a.s(["default",0,i,"useCarousel",0,(b={})=>{let[d,e]=(0,c.useState)(0),f=(0,c.useRef)(),g=(0,c.useCallback)(c=>{if(null!==c){let d=new(a.r(21207))(c,{prevNextButtons:!1,pageDots:!1,wrapAround:!0,dragThreshold:5,...b});f.current=d,d.on("dragStart",()=>{document.ontouchmove=a=>{a.preventDefault()}}),d.on("dragEnd",()=>{document.ontouchmove=()=>!0})}},[f,b]);return(0,c.useEffect)(()=>{f&&f.current&&f.current.on("change",a=>{e(a)})},[f]),(0,c.useEffect)(()=>()=>{f.current&&f.current.destroy()},[f]),{flickity:g,flickityIndex:d,setFlickityIndex:a=>{f&&f.current&&f.current.select(a,!0)}}}])},21934,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(46283),g=a.i(27899),h=a.i(36437),i=b([h]);[h]=i.then?(await i)():i;let j=f.default.video.withConfig({displayName:"LazyVideo__StyledVideo",componentId:"sc-98b9c8f9-0"})`
  display: block;
  width: 100%;
  height: 100%;
  object-fit: cover;
`,k=({src:a,style:b,className:c,...f})=>{let g=(0,e.useRef)(!1),[i,k]=(0,h.useInView)({rootMargin:"100%",triggerOnce:!0}),[l,m,n]=(0,h.useInView)();return(0,e.useEffect)(()=>{let a=n?.target;a&&(k&&!g.current&&(a.load(),g.current=!0),m?(a=>{if(!a)return;let b=a.play();void 0!==b&&b.then(()=>{}).catch(()=>{})})(a):((a,b=!1)=>{a&&(a.pause(),b&&(a.currentTime=0))})(a))},[m,k,n]),(0,d.jsx)("div",{style:b,className:c,ref:i,children:(0,d.jsx)(j,{playsInline:!0,preload:"none",ref:l,...f,children:(0,d.jsx)("source",{src:a})})})};k.propTypes={src:g.default.string.isRequired,className:g.default.string,style:g.default.object},a.s(["default",0,k]),c()}catch(a){c(a)}},!1),27129,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(46283),g=a.i(27899),h=a.i(51176),i=a.i(21428),j=a.i(49933),k=a.i(91169),l=a.i(72253),m=a.i(21934),n=b([k,m]);[k,m]=n.then?(await n)():n;let o=f.default.div.withConfig({displayName:"BigTextWithVideo__JumboTextWrap",componentId:"sc-efc9a74c-0"})`
  position: relative;
  text-align: center;
  font-size: 0;
`,p=(0,f.default)(m.default).withConfig({displayName:"BigTextWithVideo__MaskedVideo",componentId:"sc-efc9a74c-1"})`
  position: absolute;
  top: 1px;
  left: 1px;
  height: calc(100% - 2px);
  width: calc(100% - 2px);

  .ReactModal__Body--open & {
    opacity: 0;
  }
`,q=f.default.svg.withConfig({displayName:"BigTextWithVideo__VideoMask",componentId:"sc-efc9a74c-2"})`
  position: relative;
  font-family: var(--secondary-font);
  text-transform: uppercase;
  font-size: ${(0,j.rem)(400)};
  line-height: 0.93;

  .filler {
    visibility: hidden;
  }
`,r=f.default.rect.withConfig({displayName:"BigTextWithVideo__BGRect",componentId:"sc-efc9a74c-3"})`
  fill: var(--brand-white);
`,s=f.default.rect.withConfig({displayName:"BigTextWithVideo__BlackBox",componentId:"sc-efc9a74c-4"})`
  /* needs to be black black */
  fill: #000;
`,t=(0,f.default)(l.default).withConfig({displayName:"BigTextWithVideo__StyledPlayButton",componentId:"sc-efc9a74c-5"})`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,u=({topText:a,bottomText:b,video:c,videoId:f})=>{let{toggleModal:g}=(0,k.useModal)(),j=(0,e.useRef)(),l=(0,e.useRef)(),m=(0,e.useRef)(),n=(0,e.useCallback)(a=>{if(!a)return;let b=a.querySelector(".filler"),c=a.querySelector(".the-text"),d=a.querySelector(".black-box"),e=a.querySelector(".play-button");j.current=a,h.default.set([b,c,d],{autoAlpha:1,transformOrigin:"50% 50%"}),h.default.to(c,{x:1}),m.current=h.default.timeline({paused:!0,onComplete:()=>{l.current.progress(0).pause()}}).to(d,{opacity:1,duration:2}).fromTo(d,{opacity:1},{opacity:0,duration:1}),l.current=h.default.timeline({paused:!0,onComplete:()=>{g(f),m.current.play(0)}}).fromTo(c,{scaleY:1,scaleX:1},{scaleY:.333,scaleX:1.333,duration:.333},0).fromTo(e,{opacity:1,scale:1},{opacity:0,scale:.5},0).fromTo([b,d],{scaleY:0,scaleX:.5},{ease:"circ.inOut",scaleY:1,scaleX:1,duration:.5},0).fromTo(d,{opacity:0},{opacity:1,duration:1},"-=.333")},[g,f]);return(0,e.useEffect)(()=>()=>{l.current&&l.current.kill(),m.current&&m.current.kill()},[]),(0,d.jsxs)(o,{ref:n,children:[(0,d.jsx)(p,{muted:!0,loop:!0,playsInline:!0,src:c?.url}),(0,d.jsxs)(q,{viewBox:"0 0 1280 720",children:[(0,d.jsx)("g",{fillRule:"evenodd",children:(0,d.jsxs)("mask",{id:`text-mask-${f}`,children:[(0,d.jsx)("rect",{fill:"#fff",x:"0",y:"0",width:"1280",height:"720"}),(0,d.jsx)("rect",{className:"filler",fill:"#000",x:"0",y:"0",width:"1280",height:"720"}),(0,d.jsxs)("g",{className:"the-text",children:[(0,d.jsx)("text",{fill:"#000",x:"640",y:"345",textAnchor:"middle",children:a}),(0,d.jsx)("text",{fill:"#000",x:"640",y:"335",textAnchor:"middle",dominantBaseline:"hanging",children:b})]})]})}),(0,d.jsx)(r,{mask:`url(#text-mask-${f})`,x:"0",y:"0",width:"1280",height:"720"}),(0,d.jsx)(s,{className:"black-box",x:"0",y:"0",width:"1280",height:"720",opacity:"0"})]}),f?(0,d.jsx)(t,{className:"play-button",onClick:()=>{l.current.play(0),h.default.registerPlugin(i.default),h.default.to(window,{duration:.4,scrollTo:{y:j.current,offsetY:(window.innerHeight-j.current.getBoundingClientRect().height)/2,autoKill:!1}})},label:"Play video"}):null]})};u.propTypes={topText:g.default.string,bottomText:g.default.string,video:g.default.object,videoId:g.default.string},a.s(["default",0,u]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__fb041ebb._.js.map
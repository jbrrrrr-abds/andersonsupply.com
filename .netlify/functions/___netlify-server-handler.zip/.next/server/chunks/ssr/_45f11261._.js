module.exports=[62799,a=>{"use strict";var b=a.i(8171);a.i(27669);var c=a.i(27899),d=a.i(46283),e=a.i(74852),f=a.i(93631),g=a.i(68178),h=a.i(8444);let i=d.default.div.withConfig({displayName:"Hero__StyledHero",componentId:"sc-101fb38-0"})`
  position: relative;
  padding: 380px 0 284px;
  color: var(--brand-white);
  background: linear-gradient(180deg, rgb(0 0 0 / 47%) 11.9%, rgb(0 0 0 / 0%));
  text-align: center;

  ${e.default.below(f.bp.desktop,`
    padding: 285px 0 214px;
  `)}

  ${e.default.below(f.bp.portrait,`
    padding: 190px 0 142px;
  `)}
`,j=d.default.img.withConfig({displayName:"Hero__HeroImage",componentId:"sc-101fb38-1"})`
  position: absolute;
  top: 0;
  left: 0;
  z-index: -1;
  width: 100%;
  height: 100%;
  object-fit: cover;
`,k=({headline:a,image:c})=>(0,b.jsxs)(i,{bgColor:"brand-black",children:[c?(0,b.jsx)(j,{src:`${c?.url}&w=1800&h=740&fit=crop&q=85&f=center`,alt:c?.alt}):null,a?(0,b.jsx)(g.default,{children:(0,b.jsx)(h.Ninety,{as:"h1",children:a})}):null]});k.propTypes={headline:c.default.string,image:c.default.object},a.s(["default",0,k])},67905,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(93631),i=a.i(52227),j=a.i(10424),k=a.i(68178),l=a.i(80011),m=a.i(68150),n=a.i(94905),o=b([i,m,n]);[i,m,n]=o.then?(await o)():o;let p=(0,f.default)(j.default).withConfig({displayName:"Intro__StyledSection",componentId:"sc-ecc8e848-0"})`
  padding-bottom: 0;
`,q=(0,f.default)(i.default).withConfig({displayName:"Intro__StyledImageWithText",componentId:"sc-ecc8e848-1"})`
  padding: var(--spacing) 0;

  ${g.default.below(h.bp.laptopSm,`
    &:first-of-type {
      padding-bottom: 30px;
    }
  `)}
`,r=({introTitle:a,introDescription:b,introImage:c,smallImage:e,bigImage:f})=>(0,d.jsx)(p,{bgColor:"brand-white",children:(0,d.jsx)(k.default,{children:(0,d.jsxs)(l.default,{children:[(0,d.jsxs)(q,{imageLeft:!0,image:c,children:[a?(0,d.jsx)("h2",{children:a}):null,b?(0,d.jsx)(n.default,{content:b}):null]}),(0,d.jsx)(m.default,{smallImage:e,bigImage:f})]})})});r.propTypes={introTitle:e.default.string,introDescription:e.default.array,introImage:e.default.object,smallImage:e.default.object,bigImage:e.default.object},a.s(["default",0,r]),c()}catch(a){c(a)}},!1),21368,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(27899),g=a.i(51176),h=a.i(43124),i=a.i(46283),j=a.i(74852),k=a.i(93631),l=a.i(91169),m=a.i(10424),n=a.i(72253),o=a.i(15935),p=a.i(8444),q=b([l]);[l]=q.then?(await q)():q;let r=i.default.div.withConfig({displayName:"Video__VideoSectionWrapper",componentId:"sc-3ab79823-0"})`
  padding-top: var(--spacing);
  background-color: var(--brand-white);
`,s=(0,i.default)(m.default).withConfig({displayName:"Video__VideoSection",componentId:"sc-3ab79823-1"})`
  position: relative;
  padding: 436px 0;
  overflow: hidden;
  color: var(--brand-white);

  ${j.default.below(k.bp.desktopSm,`
    padding: 326px 0;
  `)}

  ${j.default.below(k.bp.laptopSm,`
    padding: 218px 0;
  `)}
`,t=(0,i.default)(o.default).withConfig({displayName:"Video__List",componentId:"sc-3ab79823-2"})`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,u=(0,i.default)(n.default).withConfig({displayName:"Video__StyledPlayButton",componentId:"sc-3ab79823-3"})`
  position: absolute;
  top: 50%;
  left: 50%;
  transform: translate(-50%, -50%);
`,v=({videoId:a})=>{let{toggleModal:b}=(0,l.useModal)(),c=Array.from(Array(10),()=>"play"),f=(0,e.useRef)(),i=(0,e.useRef)(1),j=(0,e.useCallback)(b=>{if(!b)return;g.default.registerPlugin(h.default);let c=b.children;f.current=g.default.to(c,{yPercent:100,duration:2,ease:"none",repeat:-1,onReverseComplete(){this.totalTime(100*this.duration()+this.rawTime())}}),h.default.create({trigger:b,id:`${a}-play`,start:"top bottom",end:"bottom top",animation:f.current,toggleActions:"play pause resume reset",onUpdate(a){i.current!==a.direction&&(g.default.to(f.current,{duration:1.5,ease:"slow(0.1, 0.7, false)",timeScale:a.direction}),i.current=a.direction)}})},[a]);return((0,e.useEffect)(()=>()=>{h.default.getById(`${a}-play`)&&h.default.getById(`${a}-play`).kill(),f.current&&f.current.kill()},[a]),a)?(0,d.jsx)(r,{children:(0,d.jsxs)(s,{bgColor:"brand-black",children:[c?.length>0?(0,d.jsx)(t,{ref:j,"aria-hidden":"true",children:c.map((a,b)=>(0,d.jsx)("li",{children:(0,d.jsx)(p.OneSixty,{children:a})},b))}):null,a?(0,d.jsx)(u,{onClick:()=>{b(a)},"aria-label":"Play video"}):null]})}):null};v.propTypes={videoId:f.default.string},a.s(["default",0,v]),c()}catch(a){c(a)}},!1),41005,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(93631),i=a.i(10424),j=a.i(68178),k=a.i(760),l=a.i(80011),m=a.i(68150),n=a.i(64472),o=a.i(8444),p=a.i(94905),q=b([m,p]);[m,p]=q.then?(await q)():q;let r=(0,f.default)(k.default).withConfig({displayName:"Value__ValueGrid",componentId:"sc-6a49e912-0"})`
  grid-template-columns: 1fr 520px;
  align-items: center;
  justify-content: space-between;
  max-width: 1394px;

  ${a=>a.valueTitle&&`
    margin: auto auto 144px;

    ${g.default.below(h.bp.desktopSm,`
      margin-bottom: 108px;
    `)}

    ${g.default.below(h.bp.laptopSm,`
      margin-bottom: 72px;
    `)}
  `}

  ${g.default.below(h.bp.desktop,`
    grid-template-columns: 1fr 1.2fr;
    grid-gap: 60px;
  `)}

  ${g.default.below(h.bp.laptopSm,`
    grid-template-columns: repeat(2, 1fr);
  `)}

  ${g.default.below(h.bp.portrait,`
    grid-template-columns: 1fr;
  `)}
`,s=f.default.div.withConfig({displayName:"Value__Content",componentId:"sc-6a49e912-1"})`
  max-width: 540px;
`,t=({valueTitle:a,valueSubTitle:b,valueDescription:c,valueLink:e,valueLinkText:f,valueImageLeft:g,valueImageRight:h})=>(0,d.jsx)(i.default,{hasPadding:!0,bgColor:"white",children:(0,d.jsxs)(j.default,{children:[a||c?.length>0&&""!==c[0].text?(0,d.jsxs)(r,{children:[(0,d.jsxs)(s,{children:[a?(0,d.jsx)("h2",{children:a}):null,c?.length>0&&""!==c[0].text?(0,d.jsx)(p.default,{content:c}):null,e.url?(0,d.jsx)(n.default,{large:!0,isdark:!0,bgcolor:"gold",hasmargin:!0,href:e?.url,children:f}):null]}),(0,d.jsx)("div",{children:b?(0,d.jsx)(o.Ninety,{children:b}):null})]}):null,(0,d.jsx)(l.default,{children:(0,d.jsx)(m.default,{smallImageLeft:!0,smallImage:g,bigImage:h})})]})});t.propTypes={valueTitle:e.default.string,valueSubTitle:e.default.string,valueDescription:e.default.array,valueLink:e.default.object,valueLinkText:e.default.string,valueImageLeft:e.default.object,valueImageRight:e.default.object},a.s(["default",0,t]),c()}catch(a){c(a)}},!1),1060,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(65762),f=a.i(47659),g=a.i(12841),h=a.i(62799),i=a.i(67905),j=a.i(21368),k=a.i(57915),l=a.i(41005),m=a.i(75305),n=a.i(9959),o=a.i(91169),p=a.i(10512),q=b([f,g,i,j,k,l,m,n,o]);async function r({params:a,preview:b,previewData:c}){let d=(0,f.createClient)({previewData:c}),e=await d.getByUID("services_single",a.uid)||{},g=await d.getSingle("marquee")||{};return{props:{page:e,marquee:g}}}async function s(){let a=await (0,f.createClient)().get({predicates:g.filter.at("document.type","services_single")});return{paths:a?.results?.map(a=>({params:{uid:a.uid}})),fallback:!1}}[f,g,i,j,k,l,m,n,o]=q.then?(await q)():q,a.s(["default",0,({page:a,marquee:b})=>{let{modalOpen:c}=(0,o.useModal)();if(!a)return null;let{data:f}=a,{data:g}=b;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.Helmet,{title:f.page_title,meta:[{name:"description",content:f?.page_description},{property:"og:title",content:f?.page_title},{property:"og:description",content:f?.page_description},{property:"og:image",content:`${f?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:image",content:`${f?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:title",content:f?.page_title},{name:"twitter:description",content:f?.page_description}]}),(0,d.jsxs)("main",{children:[(0,d.jsx)(h.default,{headline:f?.hero_title,image:f?.hero_image}),(0,d.jsx)(i.default,{introTitle:f?.intro_title,introDescription:f?.intro_description,introImage:f?.intro_image,smallImage:f?.image_grid_left_image,bigImage:f?.image_grid_right_image}),(0,d.jsx)(j.default,{videoId:f?.video_id}),(0,d.jsx)(k.default,{image:f?.quote_image,quote:f?.quote,quotee:f?.quotee,title:f?.quote_title,description:f?.quote_description,link:f?.quote_link,linkText:f?.quote_link_text}),(0,d.jsx)(l.default,{valueTitle:f?.value_title,valueSubTitle:f?.value_sub_title,valueDescription:f?.value_description,valueLink:f?.value_link,valueLinkText:f?.value_link_text,valueImageLeft:f?.value_image_left,valueImageRight:f?.value_image_right}),(0,d.jsx)(m.default,{marqueeID:a?.id,content:g})]}),(0,d.jsx)(n.default,{children:(0,d.jsx)(p.default,{youTubeID:c})})]})},"getStaticPaths",()=>s,"getStaticProps",()=>r]),c()}catch(a){c(a)}},!1),33282,a=>a.a(async(b,c)=>{try{var d=a.i(76164),e=a.i(23503),f=a.i(92188),g=a.i(67684),h=a.i(76695),i=a.i(1060),j=a.i(76441),k=b([h,i]);[h,i]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/services/[uid]",pathname:"/services/[uid]",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/services/[uid]",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_45f11261._.js.map
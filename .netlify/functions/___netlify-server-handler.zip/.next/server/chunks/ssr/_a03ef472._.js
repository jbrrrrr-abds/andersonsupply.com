module.exports=[10424,a=>{"use strict";var b=a.i(46283);let c=b.default.section.withConfig({displayName:"Section",componentId:"sc-47f70e12-0"})`
  ${a=>a.hasPadding&&`
    padding: var(--spacing) 0;
  `}

  ${a=>a.bgColor&&`
    background-color: var(--${a.bgColor});
  `}
`;a.s(["default",0,c])},31490,a=>{"use strict";var b=a.i(46283),c=a.i(27899);let d=b.default.div.withConfig({displayName:"VisuallyHidden",componentId:"sc-b26996ff-0"})`
  position: absolute;
  top: 0;
  left: -999px;
  pointer-events: none;
  clip-path: inset(0 100% 100% 0);
`;d.propTypes={as:c.default.string},a.s(["default",0,d])},2669,a=>{"use strict";var b=a.i(8171);a.i(27669);var c=a.i(46283),d=a.i(74852),e=a.i(49933),f=a.i(93631),g=a.i(10424),h=a.i(68178),i=a.i(31490),j=a.i(8444),k=a.i(15935),l=a.i(760),m=a.i(64472),n=a.i(6912);let o=(0,c.default)(g.default).withConfig({displayName:"Hero__StyledSection",componentId:"sc-dcd3d238-0"})`
  padding: 314px 0 var(--spacing);
  text-align: center;

  ${d.default.below(f.bp.desktop,`
    padding-top: 235px;
  `)}

  ${d.default.below(f.bp.laptopSm,`
    padding-top: 157px;
  `)}
`,p=c.default.div.withConfig({displayName:"Hero__Graphic",componentId:"sc-dcd3d238-1"})`
  position: relative;
  max-width: 580px;
  margin: auto auto 40px;

  ${d.default.below(f.bp.desktop,`
    max-width: 435px;
    margin-bottom: 30px;
  `)}

  ${d.default.below(f.bp.laptopSm,`
    max-width: 290px;
    margin-bottom: 20px;
  `)}
`,q=(0,c.default)(j.Forty).withConfig({displayName:"Hero__StyledForty",componentId:"sc-dcd3d238-2"})`
  ${d.default.below(f.bp.portrait,`
    max-width: 480px;
    margin: auto;
    line-height: 1.2;
  `)}
`,r=c.default.span.withConfig({displayName:"Hero__GridTitle",componentId:"sc-dcd3d238-3"})`
  display: block;
  margin-top: 15px;
  font-size: ${(0,e.rem)(15)};
  font-weight: 700;
  text-transform: uppercase;
`,s=(0,c.default)(l.default).withConfig({displayName:"Hero__StyledGrid",componentId:"sc-dcd3d238-4"})`
  position: relative;
  grid-template-columns: repeat(2, 1fr);
  column-gap: 170px;
  max-width: 1000px;
  margin: 26px auto 34px;

  span {
    display: block;
    color: var(--gold);
    font-size: ${(0,e.rem)(18)};
    font-family: var(--secondary-font);
  }

  p {
    opacity: .6;

    &:first-of-type {
      margin-top: 0;
    }

    &:last-of-type {
      margin-bottom: 0;
    }
  }

  &::before {
    ${d.default.above(f.bp.tablet,`
      position: absolute;
      top: 0;
      left: 50%;
      width: 1px;
      height: 100%;
      background-color: var(--brand-black);
      transform: translateX(-50%);
      content: "";
    `)}
  }

  ${d.default.below(f.bp.tablet,`
    grid-template-columns: 1fr;
    grid-row-gap: 40px;
    max-width: 450px;
  `)}

  ${d.default.below(f.bp.mobile,`
    grid-row-gap: 20px;
    margin-bottom: 0;
  `)}
`,t=()=>(0,b.jsx)(o,{hasPadding:!0,bgColor:"brand-white",children:(0,b.jsxs)(h.default,{children:[(0,b.jsx)(i.default,{as:"h1",children:"404"}),(0,b.jsx)(p,{children:(0,b.jsx)(n.default,{src:"/images/404-duke.png",alt:"",width:580,height:415})}),(0,b.jsx)(q,{children:"We couldn't find the page you were looking for"}),(0,b.jsx)(r,{children:"This is Either Because:"}),(0,b.jsxs)(s,{as:k.default,children:[(0,b.jsxs)("li",{children:[(0,b.jsx)("span",{children:"01"}),(0,b.jsx)("p",{children:"There is an error in the URL entered into your web browser. Please check the URL and try again."})]}),(0,b.jsxs)("li",{children:[(0,b.jsx)("span",{children:"02"}),(0,b.jsx)("p",{children:"The page you are looking for has been moved or deleted."})]})]}),(0,b.jsx)(m.default,{href:"/",isdark:!0,bgcolor:"gold",large:!0,hasmargin:!0,children:"Back to Home"})]})});a.s(["default",0,()=>(0,b.jsx)(t,{})],2669)},78476,a=>a.a(async(b,c)=>{try{var d=a.i(43308),e=a.i(81245),f=a.i(42158),g=a.i(67684),h=a.i(76695),i=a.i(2669),j=a.i(42369),k=b([h]);[h]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/404",pathname:"/404",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/404",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_a03ef472._.js.map
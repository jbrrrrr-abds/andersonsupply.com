module.exports=[21689,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(93631),i=a.i(10424),j=a.i(68178),k=a.i(27129),l=b([k]);[k]=l.then?(await l)():l;let m=(0,f.default)(i.default).withConfig({displayName:"Video__StyledSection",componentId:"sc-95b83b78-0"})`
  padding: 320px 0 var(--spacing);

  ${g.default.below(h.bp.desktop,`
    padding-top: 240px;
  `)}

  ${g.default.below(h.bp.laptopSm,`
    padding-top: 160px;
  `)}
`,n=({topText:a,bottomText:b,video:c,videoId:e})=>(0,d.jsx)(m,{bgColor:"brand-white",children:(0,d.jsx)(j.default,{children:(0,d.jsx)(k.default,{topText:a,bottomText:b,video:c,videoId:e})})});n.propTypes={topText:e.default.string,bottomText:e.default.string,video:e.default.object,videoId:e.default.string},a.s(["default",0,n]),c()}catch(a){c(a)}},!1),77086,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(93631),i=a.i(35688),j=a.i(10424),k=a.i(68178),l=a.i(760),m=a.i(8444),n=a.i(68150),o=a.i(15935),p=a.i(94905),q=b([n,p]);[n,p]=q.then?(await q)():q;let r=(0,f.default)(l.default).withConfig({displayName:"CarouselBlock__StyledGrid",componentId:"sc-ea74d0d-0"})`
  grid-template-columns: 1fr 1.2fr;
  max-width: 1390px;
  margin: auto;
  color: var(--brand-white);

  p {
    max-width: 540px;
  }

  ${g.default.below(h.bp.laptopSm,`
    grid-template-columns: 1fr 2fr;
  `)}

  ${g.default.below(h.bp.portrait,`
    grid-template-columns: 1fr;

    h2 {
      margin-top: 38px;
    }
  `)}
`,s=f.default.div.withConfig({displayName:"CarouselBlock__Wrapper",componentId:"sc-ea74d0d-1"})`
  position: relative;
  margin-top: 94px;

  ${g.default.below(h.bp.desktopSm,`
    margin-top: 70px;
  `)}

  ${g.default.below(h.bp.laptopSm,`
    margin-top: 48px;
  `)}
`,t=f.default.nav.withConfig({displayName:"CarouselBlock__CarouselNavigation",componentId:"sc-ea74d0d-2"})`
  width: 92px;
  margin-top: 16px;

  ul {
    display: flex;
    justify-content: space-between;
  }
`,u=({title:a,subTitle:b,description:c,slides:e=[]})=>{let{flickity:f,setFlickityIndex:g,flickityIndex:h}=(0,i.useCarousel)();return(0,d.jsx)(j.default,{hasPadding:!0,bgColor:"brand-black",children:(0,d.jsxs)(k.default,{children:[(0,d.jsxs)(r,{children:[(0,d.jsx)("div",{children:a?(0,d.jsx)(m.Ninety,{children:a}):null}),(0,d.jsxs)("div",{children:[b?(0,d.jsx)("h2",{children:b}):null,c?(0,d.jsx)(p.default,{content:c}):null]})]}),(0,d.jsx)(s,{children:(0,d.jsx)(i.default,{ref:f,children:e.map((a,b)=>(0,d.jsx)(i.default.Slide,{children:(0,d.jsx)(n.default,{smallImageLeft:!0,smallImage:a?.left_image,bigImage:a?.right_image})},b))})}),(0,d.jsx)(t,{"aria-label":"About Us Carousel",children:(0,d.jsxs)(o.default,{children:[(0,d.jsx)("li",{children:(0,d.jsx)(i.default.Button,{slideCount:e.length,currentIndex:h,handleClick:g,action:"prev",color:"brand-white"})}),(0,d.jsx)("li",{children:(0,d.jsx)(i.default.Button,{slideCount:e.length,currentIndex:h,handleClick:g,isLeft:!0,action:"next",color:"brand-white"})})]})})]})})};u.propTypes={title:e.default.string,subTitle:e.default.string,description:e.default.array,slides:e.default.array},a.s(["default",0,u]),c()}catch(a){c(a)}},!1),81563,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(93631),i=a.i(10424),j=a.i(760),k=a.i(15749),l=a.i(94905),m=b([k,l]);[k,l]=m.then?(await m)():m;let n=(0,f.default)(j.default).withConfig({displayName:"TwoColumn__StyledGrid",componentId:"sc-6df1a7f1-0"})`
  gap: 0;

  ${g.default.above(h.bp.tablet,`
    grid-template-columns: repeat(2, 1fr);
  `)}
`,o=f.default.div.withConfig({displayName:"TwoColumn__ImageColumn",componentId:"sc-6df1a7f1-1"})`
  position: relative;
`,p=f.default.div.withConfig({displayName:"TwoColumn__ContentColumn",componentId:"sc-6df1a7f1-2"})`
  padding: var(--spacing) 146px;

  ${g.default.below(h.bp.desktop,`
    padding: var(--spacing) 110px;
  `)}

  ${g.default.below(h.bp.laptop,`
    padding: var(--spacing) 60px;
  `)}

  ${g.default.below(h.bp.tablet,`
    padding: var(--spacing) var(--container-gutter);
  `)}
`,q=(0,f.default)(k.default).withConfig({displayName:"TwoColumn__AbsoluteImage",componentId:"sc-6df1a7f1-3"})`
  ${g.default.above(h.bp.tablet,`
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;

    img {
      position: absolute;
      top: 0;
      left: 0;
      width: 100%;
      height: 100%;
      object-fit: cover;
    }
  `)}
`,r=({title:a,description:b,image:c})=>(0,d.jsx)(i.default,{bgColor:"brand-white",children:(0,d.jsxs)(n,{children:[(0,d.jsx)(o,{children:c?(0,d.jsx)(q,{src:`${c?.url}&w=900&h=900&fit=crop&q=85&f=center`,alt:c?.alt,width:900,height:900}):null}),(0,d.jsxs)(p,{children:[a?(0,d.jsx)("h2",{children:a}):null,b?(0,d.jsx)(l.default,{content:b}):null]})]})});r.propTypes={title:e.default.string,description:e.default.array,image:e.default.object},a.s(["default",0,r]),c()}catch(a){c(a)}},!1),74913,a=>a.a(async(b,c)=>{try{var d=a.i(8171),e=a.i(27669),f=a.i(51176),g=a.i(43124),h=a.i(27899),i=a.i(46283),j=a.i(74852),k=a.i(23277),l=a.i(93631),m=a.i(10424),n=a.i(68178),o=a.i(760),p=a.i(15935),q=a.i(8444),r=a.i(86011),s=a.i(15749),t=a.i(45491),u=b([s]);[s]=u.then?(await u)():u;let v=(0,i.default)(m.default).withConfig({displayName:"TeamGrid__StyledSection",componentId:"sc-36bd4fcc-0"})`
  h2 {
    margin-bottom: 80px;
    text-align: center;
  }
`,w=(0,i.default)(o.default).withConfig({displayName:"TeamGrid__StyledGrid",componentId:"sc-36bd4fcc-1"})`
  grid-template-columns: repeat(4, 1fr);
  gap: 48px 20px;
  max-width: 1395px;
  margin: auto;

  li {
    visibility: hidden;
  }

  span,
  small {
    display: block;
  }

  ${j.default.below(l.bp.desktopSm,`
    grid-template-columns: repeat(3, 1fr);
  `)}

  ${j.default.below(l.bp.portrait,`
    grid-template-columns: repeat(2, 1fr);
  `)}

  ${j.default.below(l.bp.mobile,`
    grid-template-columns: 1fr;
  `)}
`,x=i.default.span.withConfig({displayName:"TeamGrid__Name",componentId:"sc-36bd4fcc-2"})`
  margin-top: 25px;
`,y=i.default.div.withConfig({displayName:"TeamGrid__Wrap",componentId:"sc-36bd4fcc-3"})`
  position: relative;

  &::before {
    content: "";
    width: 100%;
    padding-bottom: ${(0,k.default)(370,330)};
  }

  > .content {
    position: absolute;
    inset: 0;
    display: flex;
    align-items: center;
    justify-content: center;
    flex-direction: column;
  }
`,z=(0,i.default)(y).withConfig({displayName:"TeamGrid__GrowingWrap",componentId:"sc-36bd4fcc-4"})`
  display: flex;
  align-items: center;
  justify-content: center;
  color: var(--gold);
  background-color: var(--brand-white);
  text-align: center;
  transition: color 300ms ease-in-out, background-color 300ms ease-in-out;

  h3 {
    color: var(--brand-black);
  }

  svg {
    max-width: 11px;
    margin: 22px auto 16px;
    color: inherit;
  }

  ${(0,l.hover)(`
    color: var(--brand-white);
    background-color: var(--gold);
  `)}
`,A=({title:a,team:b=[],linkTopText:c,linkBottomText:h,link:i})=>{let j=(0,e.useCallback)(a=>{if(!a)return;f.default.registerPlugin(g.default);let b=a.children;b.length>0&&g.default.batch(b,{onEnter:a=>f.default.fromTo(a,{autoAlpha:0,yPercent:20},{duration:1.5,autoAlpha:1,yPercent:0,stagger:{each:.25},overwrite:!0,ease:"power2"}),id:"team-grid-trigger",start:"top 80%",end:"+=0",once:!0})},[]);return(0,e.useEffect)(()=>()=>{g.default.getById("team-grid-trigger")&&g.default.getById("team-grid-trigger").kill()},[]),(0,d.jsx)(v,{hasPadding:!0,children:(0,d.jsxs)(n.default,{children:[a?(0,d.jsx)("h2",{children:a}):null,b.length>0?(0,d.jsxs)(p.default,{ref:j,as:w,children:[b.map((a,b)=>(0,d.jsxs)("li",{children:[(0,d.jsx)(s.default,{width:330,height:370,src:`${a?.image?.url}&w=330&h=370&fit=crop&q=85&f=center`,alt:a?.image?.alt}),(0,d.jsx)(x,{children:(0,d.jsx)("strong",{children:a?.name})}),(0,d.jsx)("small",{children:a?.job_title})]},b)),(0,d.jsx)("li",{children:(0,d.jsx)(z,{as:t.default,href:i?.url,children:(0,d.jsxs)("div",{className:"content",children:[c?(0,d.jsx)(q.Sixty,{as:"h3",children:c}):null,(0,d.jsx)(r.default,{}),h?(0,d.jsx)(q.TwentyFive,{children:h}):null]})})})]}):null]})})};A.propTypes={title:h.default.string,team:h.default.array,linkTopText:h.default.string,linkBottomText:h.default.string,link:h.default.object},a.s(["default",0,A]),c()}catch(a){c(a)}},!1),3875,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(27899),f=a.i(46283),g=a.i(74852),h=a.i(49933),i=a.i(19608),j=a.i(93631),k=a.i(10424),l=a.i(68178),m=a.i(64472),n=a.i(8444),o=a.i(15749),p=a.i(94905),q=b([i,o,p]);[i,o,p]=q.then?(await q)():q;let r=(0,f.default)(k.default).withConfig({displayName:"TheDuke__StyledSection",componentId:"sc-9afada8f-0"})`
  text-align: center;

  img {
    display: block;
    margin: -50px auto auto;

    ${g.default.below(j.bp.laptopSm,`
      margin-top: -25px;
    `)}
  }

  span,
  small {
    display: block;
  }
`,s=f.default.div.withConfig({displayName:"TheDuke__BigTextWrap",componentId:"sc-9afada8f-1"})`
  max-width: 1118px;
  margin: auto;

  ${g.default.below(j.bp.desktop,`
    max-width: 840px;
  `)}

  ${g.default.below(j.bp.portrait,`
    max-width: 500px;
  `)}
`,t=f.default.div.withConfig({displayName:"TheDuke__Description",componentId:"sc-9afada8f-2"})`
  max-width: 520px;
  margin: 60px auto auto;
`,u=f.default.figure.withConfig({displayName:"TheDuke__ImageWrap",componentId:"sc-9afada8f-3"})`
  position: relative;
  text-align: left;
`,v=f.default.figcaption.withConfig({displayName:"TheDuke__ImageCaption",componentId:"sc-9afada8f-4"})`
  position: absolute;
  left: 50%;
  bottom: 10px;
  transform: translateX(-50%);

  span {
    line-height: 1;
  }

  small {
    font-size: ${(0,h.rem)(12)};
  }

  ${g.default.below(j.bp.mobile,`
    left: calc(50% + 25px);
    bottom: -25px;
  `)}
`,w=({title:a,image:b,caption:c,subCaption:e,description:f,linkUrl:g,linkText:h})=>(0,d.jsx)(r,{hasPadding:!0,bgColor:"brand-white",children:(0,d.jsxs)(l.default,{children:[a?(0,d.jsx)(s,{children:(0,d.jsx)(n.OneSixty,{children:a})}):null,(0,d.jsxs)(u,{children:[b?(0,d.jsx)(o.default,{src:`${b?.url}&w=553&h=372&fit=crop&q=85&f=center`,alt:b?.alt}):null,(0,d.jsxs)(v,{children:[c?(0,d.jsx)("span",{children:(0,d.jsx)("strong",{children:c})}):null,e?(0,d.jsx)("small",{children:e}):null]})]}),f?(0,d.jsx)(t,{children:(0,d.jsx)(p.default,{content:f})}):null,g?(0,d.jsx)(m.default,{hasmargin:!0,isdark:!0,large:!0,bgcolor:"gold",href:(0,i.linkResolver)(g),children:h}):null]})});w.propTypes={title:e.default.string,image:e.default.object,description:e.default.array,caption:e.default.string,subCaption:e.default.string,linkUrl:e.default.object,linkText:e.default.string},a.s(["default",0,w]),c()}catch(a){c(a)}},!1),55728,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(65762),f=a.i(47659),g=a.i(21689),h=a.i(77086),i=a.i(81563),j=a.i(74913),k=a.i(3875),l=a.i(9959),m=a.i(91169),n=a.i(10512),o=b([f,g,h,i,j,k,l,m]);async function p({preview:a,previewData:b}){let c=(0,f.createClient)({previewData:b});return{props:{page:await c.getSingle("about")||{}}}}[f,g,h,i,j,k,l,m]=o.then?(await o)():o,a.s(["default",0,({page:a})=>{let{modalOpen:b}=(0,m.useModal)();if(!a)return null;let{data:c}=a;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.Helmet,{title:c?.page_title,meta:[{name:"description",content:c?.page_description},{property:"og:title",content:c?.page_title},{property:"og:description",content:c?.page_description},{property:"og:image",content:`${c?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:image",content:`${c?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:title",content:c?.page_title},{name:"twitter:description",content:c?.page_description}]}),(0,d.jsxs)("main",{children:[(0,d.jsx)(g.default,{topText:c?.hero_top_text,bottomText:c?.hero_bottom_text,video:c?.hero_video,videoId:c?.hero_video_id}),(0,d.jsx)(h.default,{title:c?.intro_title,subTitle:c?.intro_sub_title,description:c?.intro_description,slides:c?.intro_carousel}),(0,d.jsx)(i.default,{title:c?.two_column_title,description:c?.two_column_description,image:c?.two_column_image}),(0,d.jsx)(j.default,{title:c?.team_grid_title,team:c?.team_member,linkTopText:c?.team_grid_link_top_text,linkBottomText:c?.team_grid_link_bottom_text,link:c?.team_grid_link}),(0,d.jsx)(k.default,{title:c?.pre_footer_title,image:c?.pre_footer_image,caption:c?.pre_footer_caption,subCaption:c?.pre_footer_sub_caption,description:c?.pre_footer_description,linkUrl:c?.pre_footer_link,linkText:c?.pre_footer_link_text})]}),(0,d.jsx)(l.default,{children:(0,d.jsx)(n.default,{youTubeID:b})})]})},"getStaticProps",()=>p]),c()}catch(a){c(a)}},!1),73082,a=>a.a(async(b,c)=>{try{var d=a.i(43308),e=a.i(81245),f=a.i(42158),g=a.i(67684),h=a.i(76695),i=a.i(55728),j=a.i(42369),k=b([h,i]);[h,i]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/about/index",pathname:"/about",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/about/index",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=_5de44dad._.js.map
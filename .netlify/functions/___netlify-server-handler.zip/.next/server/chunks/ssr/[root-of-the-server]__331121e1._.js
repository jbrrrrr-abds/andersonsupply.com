module.exports=[10424,a=>{"use strict";var b=a.i(46283);let c=b.default.section.withConfig({displayName:"Section",componentId:"sc-47f70e12-0"})`
  ${a=>a.hasPadding&&`
    padding: var(--spacing) 0;
  `}

  ${a=>a.bgColor&&`
    background-color: var(--${a.bgColor});
  `}
`;a.s(["default",0,c])},6077,(a,b,c)=>{b.exports=a.x("prismic-reactjs",()=>require("prismic-reactjs"))},94905,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(46283),f=a.i(27899),g=a.i(6077),h=a.i(93631),i=a.i(19608),j=a.i(45491),k=b([i]);[i]=k.then?(await k)():k;let l=(0,e.default)(j.default).withConfig({displayName:"TextBlock__StyledLink",componentId:"sc-facd1adf-0"})`
  color: var(--gold);
  text-decoration: none;
  position: relative;
  transition: color 300ms ease;

  &::after {
    content: "";
    width: 100%;
    height: 2px;
    background: var(--brand-black);
    position: absolute;
    left: 0;
    bottom: -1px;
    transition: color 300ms ease;
  }

  ${(0,h.hover)(`
    color: var(--brand-black);

    &::after {
      color: var(--gold);
    }
  `)}
`,m=(a,b,c)=>(0,d.jsx)(l,{href:(0,i.linkResolver)(b.data),children:c},`${b.data.link_type}${b.start}`),n=({content:a,...b})=>a?(0,d.jsx)(g.RichText,{render:a,serializeHyperlink:m,...b}):null;n.propTypes={content:f.default.array},a.s(["default",0,n]),c()}catch(a){c(a)}},!1),31164,a=>{"use strict";var b=a.i(46283);let c=b.default.img.withConfig({displayName:"AbsoluteImage",componentId:"sc-7b648c5d-0"})`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`;a.s(["default",0,c])},75875,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(46283),f=a.i(74852),g=a.i(93631),h=a.i(19608),i=a.i(10424),j=a.i(68178),k=a.i(8444),l=a.i(64472),m=a.i(31164),n=a.i(94905),o=a.i(45491),p=b([h,n]);[h,n]=p.then?(await p)():p;let q=(0,e.default)(i.default).withConfig({displayName:"Hero__StyledSection",componentId:"sc-f75056aa-0"})`
  position: relative;
  z-index: 1;
  padding: 418px 0 800px;
  color: var(--white);
  text-align: center;

  h1 {
    max-width: 1010px;
    margin: auto auto 34px;
  }

  h2 {
    font-size: 16px;
  }

  p {
    max-width: 880px;
    margin: auto;

    &:last-of-type {
      margin-bottom: 0;
    }
  }

  img {
    z-index: -1;
  }

  ${f.default.below(g.bp.desktop,`
    padding: 314px 0 360px;
  `)}

  ${f.default.below(g.bp.desktopSm,`
    padding: 210px 0 240px;
  `)}
`,r=e.default.div.withConfig({displayName:"Hero__Received",componentId:"sc-f75056aa-1"})`
  max-width: 330px;
  padding: 20px;
  margin: auto auto 116px;
  border: 3px solid var(--gold);

  span {
    display: block;
  }

  ${f.default.below(g.bp.desktopSm,`
    margin-bottom: 88px;
  `)}

  ${f.default.below(g.bp.laptopSm,`
    margin-bottom: 58px;
  `)}
`,s=e.default.div.withConfig({displayName:"Hero__LinkWrap",componentId:"sc-f75056aa-2"})`
  display: grid;
  grid-auto-flow: column;
  gap: 20px;
  justify-content: center;
`,t=(0,e.default)(o.default).withConfig({displayName:"Hero__StyledLink",componentId:"sc-f75056aa-3"})`
  color: var(--gold);
  text-decoration: underline;

  ${(0,g.hover)("color: var(--brand-white)")}
`;a.s(["default",0,({content:a})=>(0,d.jsxs)(q,{bgColor:"brand-black",children:[(0,d.jsxs)(j.default,{children:[(0,d.jsxs)(r,{children:[(0,d.jsx)("img",{src:"/images/contact/check.svg",alt:""}),(0,d.jsx)("span",{children:"Submission received"})]}),a?.hero_headline?(0,d.jsx)(k.OneThirty,{as:"h1",children:a.hero_headline}):null,a?.hero_description?(0,d.jsx)(n.default,{content:a.hero_description}):null,(0,d.jsxs)(s,{children:[a?.hero_link?(0,d.jsx)(l.default,{href:(0,h.linkResolver)(a?.hero_link),large:!0,hasmargin:!0,isdark:!0,bgcolor:"gold",children:a?.hero_link_text}):null,a?.hero_secondary_link?(0,d.jsx)(t,{href:(0,h.linkResolver)(a.hero_secondary_link),children:a.hero_secondary_link_text}):null]})]}),a?.hero_image?.url?(0,d.jsx)(m.default,{src:a.hero_image.url,alt:a.hero_image.alt}):null]})]),c()}catch(a){c(a)}},!1),19334,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(65762),f=a.i(47659),g=a.i(75875),h=b([f,g]);async function i({preview:a,previewData:b}){let c=(0,f.createClient)({previewData:b});return{props:{page:await c.getSingle("confirmed")||{}}}}[f,g]=h.then?(await h)():h,a.s(["default",0,({page:a})=>{if(!a)return null;let{data:b}=a;return(0,d.jsxs)(d.Fragment,{children:[(0,d.jsx)(e.Helmet,{title:b?.page_title,meta:[{name:"description",content:b?.page_description},{property:"og:title",content:b?.page_title},{property:"og:description",content:b?.page_description},{property:"og:image",content:`${b?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:image",content:`${b?.page_social_image?.url}&w=1200&h=630&fit=crop&q=85&f=center`},{name:"twitter:title",content:b?.page_title},{name:"twitter:description",content:b?.page_description},{name:"robots",content:"noindex"}]}),(0,d.jsx)(g.default,{content:b})]})},"getStaticProps",()=>i]),c()}catch(a){c(a)}},!1),68063,a=>a.a(async(b,c)=>{try{var d=a.i(76164),e=a.i(23503),f=a.i(92188),g=a.i(67684),h=a.i(76695),i=a.i(19334),j=a.i(76441),k=b([h,i]);[h,i]=k.then?(await k)():k;let l=(0,f.hoist)(i,"default"),m=(0,f.hoist)(i,"getStaticProps"),n=(0,f.hoist)(i,"getStaticPaths"),o=(0,f.hoist)(i,"getServerSideProps"),p=(0,f.hoist)(i,"config"),q=(0,f.hoist)(i,"reportWebVitals"),r=(0,f.hoist)(i,"unstable_getStaticProps"),s=(0,f.hoist)(i,"unstable_getStaticPaths"),t=(0,f.hoist)(i,"unstable_getStaticParams"),u=(0,f.hoist)(i,"unstable_getServerProps"),v=(0,f.hoist)(i,"unstable_getServerSideProps"),w=new d.PagesRouteModule({definition:{kind:e.RouteKind.PAGES,page:"/confirmed",pathname:"/confirmed",bundlePath:"",filename:""},distDir:".next",relativeProjectDir:"",components:{App:h.default,Document:g.default},userland:i}),x=(0,j.getHandler)({srcPage:"/confirmed",config:p,userland:i,routeModule:w,getStaticPaths:n,getStaticProps:m,getServerSideProps:o});a.s(["config",0,p,"default",0,l,"getServerSideProps",0,o,"getStaticPaths",0,n,"getStaticProps",0,m,"handler",0,x,"reportWebVitals",0,q,"routeModule",0,w,"unstable_getServerProps",0,u,"unstable_getServerSideProps",0,v,"unstable_getStaticParams",0,t,"unstable_getStaticPaths",0,s,"unstable_getStaticProps",0,r]),c()}catch(a){c(a)}},!1)];

//# sourceMappingURL=%5Broot-of-the-server%5D__331121e1._.js.map
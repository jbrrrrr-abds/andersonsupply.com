module.exports=[31164,a=>{"use strict";var b=a.i(46283);let c=b.default.img.withConfig({displayName:"AbsoluteImage",componentId:"sc-7b648c5d-0"})`
  position: absolute;
  top: 0;
  left: 0;
  width: 100%;
  height: 100%;
  object-fit: cover;
`;a.s(["default",0,c])},10424,a=>{"use strict";var b=a.i(46283);let c=b.default.section.withConfig({displayName:"Section",componentId:"sc-47f70e12-0"})`
  ${a=>a.hasPadding&&`
    padding: var(--spacing) 0;
  `}

  ${a=>a.bgColor&&`
    background-color: var(--${a.bgColor});
  `}
`;a.s(["default",0,c])},6077,(a,b,c)=>{b.exports=a.x("prismic-reactjs",()=>require("prismic-reactjs"))},94905,a=>a.a(async(b,c)=>{try{var d=a.i(8171);a.i(27669);var e=a.i(46283),f=a.i(27899),g=a.i(6077),h=a.i(93631),i=a.i(19608),j=a.i(45491),k=b([i]);[i]=k.then?(await k)():k;let l=(0,e.default)(j.default).withConfig({displayName:"TextBlock__StyledLink",componentId:"sc-facd1adf-0"})`
  color: var(--gold);
  text-decoration: none;
  position: relative;
  transition: color 300ms ease;

  &::after {
    content: "";
    width: 100%;
    height: 2px;
    background: var(--brand-black);
    position: absolute;
    left: 0;
    bottom: -1px;
    transition: color 300ms ease;
  }

  ${(0,h.hover)(`
    color: var(--brand-black);

    &::after {
      color: var(--gold);
    }
  `)}
`,m=(a,b,c)=>(0,d.jsx)(l,{href:(0,i.linkResolver)(b.data),children:c},`${b.data.link_type}${b.start}`),n=({content:a,...b})=>a?(0,d.jsx)(g.RichText,{render:a,serializeHyperlink:m,...b}):null;n.propTypes={content:f.default.array},a.s(["default",0,n]),c()}catch(a){c(a)}},!1),21428,(a,b,c)=>{b.exports=a.x("gsap/dist/ScrollToPlugin.js",()=>require("gsap/dist/ScrollToPlugin.js"))},31490,a=>{"use strict";var b=a.i(46283),c=a.i(27899);let d=b.default.div.withConfig({displayName:"VisuallyHidden",componentId:"sc-b26996ff-0"})`
  position: absolute;
  top: 0;
  left: -999px;
  pointer-events: none;
  clip-path: inset(0 100% 100% 0);
`;d.propTypes={as:c.default.string},a.s(["default",0,d])},5235,(a,b,c)=>{b.exports=a.x("gsap/dist/Draggable.js",()=>require("gsap/dist/Draggable.js"))},92802,(a,b,c)=>{b.exports=a.x("gsap/dist/InertiaPlugin.js",()=>require("gsap/dist/InertiaPlugin.js"))},40576,a=>{"use strict";var b=a.i(8171);a.i(27669);var c=a.i(27899),d=a.i(46283),e=a.i(93631),f=a.i(74852),g=a.i(68178),h=a.i(8444),i=a.i(10424);let j=d.keyframes`
  0% {
    transform: translateX(0);
  }

  100% {
    transform: translateX(-50%);
  }
`,k=(0,d.default)(i.default).withConfig({displayName:"BlackLogoGrid__Wrapper",componentId:"sc-99f4a700-0"})`
  --title-width: 400px;

  position: relative;
  padding: ${a=>a.title?"372px 0 308px":"380px 0"};
  color: var(--brand-white);
  overflow: hidden;

  ${a=>f.default.below(e.bp.desktopSm,`
    --title-width: 280px;
    padding: ${a.title?"300px 0 230px":"320px 0"};
  `)}

  ${a=>f.default.below(e.bp.portrait,`
    --title-width: 170px;
    padding: ${a.title?"220px 0 144px":"220px 0"};
  `)}
`,l=d.default.div.withConfig({displayName:"BlackLogoGrid__LogosContainer",componentId:"sc-99f4a700-1"})`
  position: absolute;
  top: ${a=>a.title?"180px":"90px"};
  left: 0;

  ${f.default.below(e.bp.portrait,`
    top: ${a=>a.title?"136px":"0"};
  `)}
`,m=d.default.div.withConfig({displayName:"BlackLogoGrid__LogosRow",componentId:"sc-99f4a700-2"})`
  font-size: 0;
  display: flex;
  flex-wrap: nowrap;
  margin: 10px 0;
  animation: 32s ${j} infinite linear;

  &:nth-of-type(even) {
    animation-direction: reverse;
  }

  img { min-width: calc(var(--title-width) * 6.1); }

`,n=(0,d.default)(h.OneSixty).withConfig({displayName:"BlackLogoGrid__Title",componentId:"sc-99f4a700-3"})`
  position: relative;
  z-index: 1;
  line-height: 1;
  width: var(--title-width);
  max-width: var(--title-width);

  &::before {
    position: absolute;
    top: 0;
    left: 0;
    z-index: -1;
    width: 100%;
    height: 100%;
    background-color: var(--brand-black);
    box-shadow: 0 0 10px 10px var(--brand-black);
    content: "";
  }

  ${f.default.below(e.bp.mobile,`
    max-width: 200px;
  `)}
`,o=({title:a,logoRowOne:c,logoRowTwo:d,logoRowThree:e,logoRowFour:f})=>(0,b.jsxs)(k,{bgColor:"brand-black",title:a,children:[a?(0,b.jsx)(g.default,{children:(0,b.jsx)(n,{as:"h1",children:a})}):null,(0,b.jsxs)(l,{title:a,children:[c?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:c.url,alt:c.alt}),(0,b.jsx)("img",{src:c.url,alt:"","aria-hidden":"true"})]}):null,d?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:d.url,alt:d.alt}),(0,b.jsx)("img",{src:d.url,alt:"","aria-hidden":"true"})]}):null,e?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:e.url,alt:e.alt}),(0,b.jsx)("img",{src:e.url,alt:"","aria-hidden":"true"})]}):null,f?(0,b.jsxs)(m,{children:[(0,b.jsx)("img",{src:f.url,alt:f.alt}),(0,b.jsx)("img",{src:f.url,alt:"","aria-hidden":"true"})]}):null]})]});o.propTypes={title:c.default.string,logoRowOne:c.default.object,logoRowTwo:c.default.object,logoRowThree:c.default.object,logoRowFour:c.default.object},a.s(["default",0,o])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__067df7dc._.js.map